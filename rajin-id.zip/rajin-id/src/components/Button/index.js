import React from 'react';
import './index.css';
function Button(props) {
  return (
      <a role="button" className="btn myButton rounded-pill" href={props.link} style={{backgroundColor: props.color}}>
        <div className="text">{props.text}</div>
      </a>
  );
}

export default Button;