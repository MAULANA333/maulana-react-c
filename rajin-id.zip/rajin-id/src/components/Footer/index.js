import React from 'react';

function index(props) {
  return (
    <div>
      {/* footer */}
      <section id='footer'>
          <div className="container">
            <div className="row mt-5">
              <div className="col-md-6">
                <div className="row justify-content-start">
                  <div className="col-2">
                    <img style={{ width: "100%" }} className="img2" src={process.env.PUBLIC_URL + '/icon/logo_tr1.png'} alt="" />
                  </div>
                  <div className="col-3">                 
                    <p className='fw-bold mt-4' style={{ fontSize: "32px", color:"#1B6A68" }}>Eduton</p>
                  </div>
                </div>
                <div className="row my-2">
                  <div className="col-md-7">
                    <p className='' style={{ fontSize: "16px", color:"#1B6A68" }}>Jam operasional kami yaitu setiap hari senin sampai dengan jumat jam 08.00 sampai 16.00 </p>
                  </div>
                </div>
                <div className="row">
                  <div className="col-1">
                    <img style={{ width: "100%", backgroundColor: "#1B6A68", borderRadius:"20%", padding: "5%" }} className="img2" src={process.env.PUBLIC_URL + '/icon/call.png'} alt="" />
                  </div>
                  <div className="col-1">
                    <img style={{ width: "100%", backgroundColor: "#1B6A68", borderRadius:"20%", padding: "5%" }} className="img2" src={process.env.PUBLIC_URL + '/icon/wa.png'} alt="" />
                  </div>
                  <div className="col-1">
                    <img style={{ width: "100%", backgroundColor: "#1B6A68", borderRadius:"20%", padding: "5%" }} className="img2" src={process.env.PUBLIC_URL + '/icon/email.png'} alt="" />
                  </div>
                  <div className="col-1">
                    <img style={{ width: "100%", backgroundColor: "#1B6A68", borderRadius:"20%", padding: "5%" }} className="img2" src={process.env.PUBLIC_URL + '/icon/instagram.png'} alt="" />
                  </div>
                </div>
              </div>  

              <div className="col-md-2">
                <div className="row ms-3">
                  <p className='fw-bold' style={{ fontSize: "20px", color:"#1B6A68" }}>Tryout</p>
                </div>
                <div className="row  ms-3">
                  <p className='' style={{ fontSize: "16px", color:"#1B6A68" }}>Gratis</p>
                </div>
                <div className="row ms-3">
                  <p className='' style={{ fontSize: "16px", color:"#1B6A68" }}>Cerdas</p>
                </div>
                <div className="row ms-3">
                  <p className='' style={{ fontSize: "16px", color:"#1B6A68" }}>Super</p>
                </div>
              </div>
              <div className="col-md-2">
                <div className="row ms-5">
                  <p className='fw-bold' style={{ fontSize: "20px", color:"#1B6A68" }}>Blog</p>
                </div>
                <div className="row ms-5">
                  <p className='' style={{ fontSize: "16px", color:"#1B6A68" }}>Event</p>
                </div>
                <div className="row ms-5">
                  <p className='' style={{ fontSize: "16px", color:"#1B6A68" }}>Artikel</p>
                </div>

              </div>
              <div className="col-md-2">
                <div className="row ms-5">
                  <p className='fw-bold' style={{ fontSize: "20px", color:"#1B6A68" }}>Tentang Kami</p>
                </div>
                <div className="row ms-5">
                  <div className="col-4">
                  <img style={{ width: "80%", backgroundColor: "#1B6A68", borderRadius:"20%", padding: "5%" }} className="img2" src={process.env.PUBLIC_URL + '/icon/wa.png'} alt="" />
                  </div>
                  <div className="col">
                  <p className='' style={{ fontSize: "16px", color:"#1B6A68", marginLeft:"-20px" }}> WhatsApp</p>
                  </div>
                </div>
                <div className="row ms-5">
                  <div className="col-4">
                  <img style={{ width: "80%", backgroundColor: "#1B6A68", borderRadius:"20%", padding: "5%" }} className="img2" src={process.env.PUBLIC_URL + '/icon/email.png'} alt="" />
                  </div>
                  <div className="col">
                  <p className='' style={{ fontSize: "16px", color:"#1B6A68", marginLeft:"-20px" }}> Email</p>
                  </div>
                </div>
                <div className="row ms-5">
                  <div className="col-4">
                  <img style={{ width: "80%", backgroundColor: "#1B6A68", borderRadius:"20%", padding: "5%" }} className="img2" src={process.env.PUBLIC_URL + '/icon/instagram.png'} alt="" />
                  </div>
                  <div className="col">
                  <p className='' style={{ fontSize: "16px", color:"#1B6A68", marginLeft:"-20px" }}> Instagram</p>
                  </div>
                </div>
              </div>
            </div>
            
          </div>
          <div className="row mt-5 " style={{ backgroundColor: "#A6DBDA", width:"100%"}}>
              <div className="container">
                <p className='text-center fw-bold my-2' style={{ fontSize: "20px", color:"#1B6A68" }}>Copyright eduton 2021. All right reserved</p>
              </div>
            </div>
         </section>
    </div>
  );
}

export default index;