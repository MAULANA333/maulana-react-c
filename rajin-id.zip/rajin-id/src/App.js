import React from 'react';
import Router from './router'
function App(props) {
  return (
   <div>
     <Router/>
   </div>
  );
}

export default App;