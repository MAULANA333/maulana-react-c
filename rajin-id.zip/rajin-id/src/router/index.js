import React from 'react';
import { Switch, Route } from 'react-router';
import LandingPage from '../pages/LandingPage';
import Blog from '../pages/Blog';
import BlogView from '../pages/BlogView';
import Katalog from '../pages/KatalogPage';
import KatalogGratis from '../pages/KatalogGratis';
import KatalogCerdas from '../pages/KatalogCerdas';
import KatalogSuper from '../pages/KatalogSuper';
import PreviewPage from '../pages/PreviewPage';
import Payment from '../pages/Payment';
import Payment2 from '../pages/Payment2';
import Certificate from '../pages/Certificate';
import Exercise from '../pages/Exercise';
import Result from '../pages/Result';
import Rank from '../pages/Rank';
import Login from '../pages/Login';
import Register from '../pages/Register';

function Router(props) {
  return (
    <Switch>
      <Route exact path='/'>
        <LandingPage/>
      </Route>
      <Route exact path='/blog'>
        <Blog/>
      </Route>
      <Route exact path='/blog/view/slug'>
        <BlogView/>
      </Route>
      <Route exact path='/katalog'>
        <Katalog/>
      </Route>
      <Route exact path='/katalog/gratis'>
        <KatalogGratis/>
      </Route>
      <Route exact path='/katalog/cerdas'>
        <KatalogCerdas/>
      </Route>
      <Route exact path='/katalog/super'>
        <KatalogSuper/>
      </Route>
      <Route exact path='/preview/slug'>
        <PreviewPage/>
      </Route>
      <Route exact path='/payment/slug'>
        <Payment/>
      </Route>
      <Route exact path='/payment/method'>
        <Payment2/>
      </Route>
      <Route exact path='/certificate'>
        <Certificate/>
      </Route>
      <Route exact path='/exercise'>
        <Exercise/>
      </Route>
      <Route exact path='/result'>
        <Result/>
      </Route>
      <Route exact path='/rank'>
        <Rank/>
      </Route>
      <Route exact path='/login'>
        <Login/>
      </Route>
      <Route exact path='/register'>
        <Register/>
      </Route>
    </Switch>
  );
}

export default Router;