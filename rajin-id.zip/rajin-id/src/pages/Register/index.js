import React from 'react';
import Navbar from '../../components/Navbar';
import Button from '../../components/Button';
import Footer from '../../components/Footer';

import './index.css';
function index(props) {
  return (
    <div id='register'>
      
      {/* navbar */}
      <Navbar/>

      {/* header */}
      <section id='header'>
        <img className="image" src={process.env.PUBLIC_URL + '/img/login.png'} alt="" />
      </section>
     <div className="box"></div>
      {/* content */}
      <section id='content'>
        <div className="container">
          <div className="row">
            <div className="col-6 px-5">
              <h1 className='fw-bold' style={{ fontSize:"72px", color:"#1B6A68" }}>Masuk</h1>
              <p className='fw-bold' style={{ fontSize:"32px", color:"#1B6A68" }}>Ayo latih pengetahuanmu bersama Eduton Id</p>
            </div>
          </div>
        </div>

        {/* form */}
            <form action="" className='form-group'>
              <div className="row justify-content-center mt-5 px-5">
                <div className="col-6 " >
                    <div className="">
                      <p className='fw-bold' style={{ fontSize:"26px", color:"#1B6A68" }}>Nama Lengkap</p>
                      <input type="text" className='form-control myInput' placeholder='Masukan Nama Lengkap'/>
                    </div>
                    <div className="mt-3">
                      <p className='fw-bold' style={{ fontSize:"26px", color:"#1B6A68" }}>Username</p>
                      <input type="text" className='form-control myInput' placeholder='Masukan Username'/>
                    </div>
                    <div className="mt-3">
                      <p className='fw-bold' style={{ fontSize:"26px", color:"#1B6A68" }}>Nama Sekolah</p>
                      <input type="text" className='form-control myInput' placeholder='Masukan Nama Sekolah'/>
                    </div>
                  
                    
                </div>
                <div className="col-6">
                <div className="">
                      <p className='fw-bold' style={{ fontSize:"26px", color:"#1B6A68" }}>Email</p>
                      <input type="text" className='form-control myInput' placeholder='Masukan Email'/>
                    </div>
                    <div className="mt-3">
                      <p className='fw-bold' style={{ fontSize:"26px", color:"#1B6A68" }}>Password</p>
                      <input type="text" className='form-control myInput' placeholder='Masukan Password'/>
                    </div>
                    <div className="mt-3">
                      <p className='fw-bold' style={{ fontSize:"26px", color:"#1B6A68" }}>Ulangi Password</p>
                      <input type="text" className='form-control myInput' placeholder='Masukan Ulang Password'/>
                    </div>
                    
                </div>
              </div>

              <div className="row justify-content-center mt-5">
                <div className="col-6">
                  <button className='btn py-4 fw-bold' style={{ borderRadius:"20px", backgroundColor:"#4DB7B5", padding:"10px 290px", fontSize:"20px", color:"#ffffff" }}>Daftar</button>
                </div>
              </div>  
              <div className="row text-center mt-4">
                <span style={{ fontSize:"", color:"#1B6A68" }}>Sudah punya akun? <span style={{ color:"1B6A68" }} className='fw-bold'>Masuk</span></span>
              </div>
            </form>

        

        {/* masih di dalam konten */}
         {/* footer */}
         <section id='footer' style={{ marginTop:"300px" }}>
          <Footer/>
        </section>

      </section>

       
    </div>
  );
}

export default index;