import React from 'react';
import Button from '../../components/Button';
import Navbar from '../../components/Navbar';
import Footer from '../../components/Footer';
import './index.css';

function index(props) {
  return (
    <div>
      <div id="landing">
        {/* header */}
        <section id="header">
          <img className="img1" src={process.env.PUBLIC_URL + '/img/Landing_Header_1.png'} alt="" />
          <div id="navbar">
            <Navbar/>
          </div>
          <div className="container">
            <div className="row justify-content-between">
              <div className="col">
                <div id="header-tittle" >
                  <h1 className=''>Mau Ujian, Butuh Latihan? Gabung aja!</h1>
                  <p>Yang kamu butuhkan untuk persiapan ujian tulis berbasis komputer, untuk persiapan masuk perguruan tinggi impian </p>
                  <div className="tombol mt-5">
                    <Button
                      link="http://localhost:3000/"
                      text="Mulai Tryout"
                      color="#1B6A68"
                    />
                  </div>
                </div>
              </div>
              <div className="col">
                
              <img className="img2" src={process.env.PUBLIC_URL + '/img/Landing_Header_2.png'} alt="" />
              <img className="img3" src={process.env.PUBLIC_URL + '/img/Landing_Header_3.png'} alt="" />
              <img className="icon1" style={{ backgroundColor: "#C36469", borderRadius: "10px", padding:"5px" }} src={process.env.PUBLIC_URL + '/icon/book-ill.png'} alt="" />
              
              <div className="box1 ">
                <div className="row">
                  <div className="col-md-4 p-3 mx-2">
                    <img className="" style={{ backgroundColor: "#20A5A2", borderRadius: "10px", padding:"5px" }} src={process.env.PUBLIC_URL + '/icon/learn.png'} alt="" />
                  </div>
                  <div className="col-md-8  mx-2">
                    <p className='fw-bold' style={{ marginTop:"-65px", marginLeft:"70px" }}> Latihan</p>
                  </div>
                  <div className="col-md-12  mx-2">
                    <p className='' style={{ marginTop:"-40px", marginLeft:"70px", fontSize:"12px" }}> Gass Latihan duluan</p>
                  </div>
                </div>
              </div>

              <div className="box2 ">
                <div className="row">
                  <div className="col-md-4 p-3 mx-2">
                    <img className="" style={{ backgroundColor: "#EBAB51", borderRadius: "10px", padding:"5px" }} src={process.env.PUBLIC_URL + '/icon/toga-ill.png'} alt="" />
                  </div>
                  <div className="col-md-8  mx-2">
                    <p className='fw-bold' style={{ marginTop:"-65px", marginLeft:"70px" }}> Selamat</p>
                  </div>
                  <div className="col-md-12  mx-2">
                    <p className='' style={{ marginTop:"-40px", marginLeft:"70px", fontSize:"12px" }}> Telah diterima di universitas favorit </p>
                  </div>
                </div>
              </div>

              <div className="box3 ">
                <div className="row">
                  <div className="col-md-4 p-2 mx-2">
                    <img className="" style={{  borderRadius: "10px", padding:"5px" }} src={process.env.PUBLIC_URL + '/icon/notif-ill.png'} alt="" />
                  </div>
                  <div className="col-md-12  mx-2">
                    <p className='fw-bold' style={{ marginTop:"-60px", marginLeft:"70px" }}> Tryout Akbar</p>
                  </div>
                  <div className="col-md-12  mx-2">
                    <p className='' style={{ marginTop:"-35px", marginLeft:"70px", fontSize:"12px" }}> Hari ini, 08.00 pagi</p>
                  </div>
                  <div className="col-md-12 ms-5" style={{ marginTop:"-10px" }}>
                    <Button
                      link="http://localhost:3000/"
                      text="ikuti sekarang"
                      color="#C36469"
                    />
                  </div>
                </div>
              </div>


              </div>
            </div>
          </div>

          {/* <img src={require('../../../public/img/wave.svg').default} alt='mySvgImage' /> */}
          {/* <img alt="Clock" src={require('../../../public/img/wave.svg')}/> */}

        </section>

        {/* features */}
        <section id="feature" >
          <div className="container">
            <div className="row justify-content-center">
              <div  className='col-md-4 mt-5'>
                <p  className='tittle-ijo'>Apasih <p className='tittle-oren'>Rajin ID itu?</p> </p>
              </div>
            </div>
            <div className="row justify-content-center mb-5">
              <div  className='col-md-8'>
                <p id='text' className='mt-5'>Rajin id adalah suatu platform yang menyediakan layanan tryout online bagi siswa untuk mempersiapkan diri menghadapi ujian, entah itu ujian masuk perguruan tinggi atau ujian nasional</p>
              </div>
            </div>

            <div className="row justify-content-between">
              <div className="col-md-6">
                <div className="img1">
                  <img src={process.env.PUBLIC_URL + '/img/feature_mix.png'} alt="" />
                </div>
              </div>
              <div className="col-md-6">
                <div className="row my-5 justify-content-center">
                  <div className="col-md-8">
                    <p className='tittle-oren' > Kalau untungnya gini, <p className='tittle-ijo'>yaa kali gak gabung. Yaa kan? </p> </p>
                  </div>
                </div>
                <div className="row ms-5 mb-3">
                  <div className="col-md-3">
                    <img  className='imgfeature' src={process.env.PUBLIC_URL + '/icon/exam.png'} alt="" />
                  </div>
                  <div className="text-feature col-md-9">
                    <p>Soal - soal tryout merupakan soal soal terpilih dan terupdate </p>
                  </div>
                </div>
                <div className="row ms-5 mb-3">
                  <div className="col-md-3">
                    <img  className='imgfeature' src={process.env.PUBLIC_URL + '/icon/score.png'} alt="" />
                  </div>
                  <div className="text-feature col-md-9">
                    <p>Tryout online menggunakan sistem penilaian IRT, serta Sekolah Kedinasan dan CPNS dengan tryout online menggunakan sistem penilaian CAT</p>
                  </div>
                </div>
                <div className="row ms-5 mb-3">
                  <div className="col-md-3">
                    <img  className='imgfeature' src={process.env.PUBLIC_URL + '/icon/teacher.png'} alt="" />
                  </div>
                  <div className="text-feature col-md-9">
                    <p>Terdapat pembahasan soal oleh mentor supaya dapat memudahkan dalam  pemahaman siswa</p>
                  </div>
                </div>
                <div className="row ms-5 mb-3">
                  <div className="col-md-3">
                    <img  className='imgfeature' src={process.env.PUBLIC_URL + '/icon/university.png'} alt="" />
                  </div>
                  <div className="text-feature col-md-9">
                    <p>Dapat memprediksi dan memberikan tips untuk siswa supaya bisa masuk ke universitas terbaik sesuai dengan nilainya</p>
                  </div>
                </div>
              </div>
            </div>

          </div>
        </section>

        {/* package */}
        <section id='package'>
          <div className="container">
            <div className="row justify-content-center">
              <div className="col-md-4  mt-5">
                <p className=' tittle-ijo '>Pilih Paket <p className='tittle-oren'>Tryout mu</p> </p>
              </div>
            </div>

            <div className="row justify-content-center mt-5 ">
              <div className="col-md-4">
                <div className="card shadow">
                  <div className="card-header mb-2" style={{ backgroundColor: "#20a5a2" }} >
                    <p className='text-center text-white' style={{fontSize: "32px"}}>Gratis !!</p>
                  </div>
                  <div className="card-body p-4"  style={{ height: "496px" }}> 
                    <div className="row">
                      <div className="col-md-3">
                        <img style={{ width: "130%" }} className="img2" src={process.env.PUBLIC_URL + '/icon/paket-gratis.png'} alt="" />
                      </div>
                      <div className="col-md-9">
                        <div className="row ms-2 fw-bold">
                          <p style={{ fontSize: "32px", color: "#1B6A68" }}>Gratis</p>
                        </div>
                        <div className="row ms-2">
                          <p style={{ fontSize: "24px", color: "#20A5A2" }}>Gratis</p>
                        </div>
                      </div>
                    </div>

                    <div className="row mt-4 ms-1">
                      <div className="col-md-2">
                        <img style={{ width: "130%" }} className="img2" src={process.env.PUBLIC_URL + '/icon/check-gratis.png'} alt="" />
                      </div>
                      <div className="col-md-10 mt-2">
                        <p style={{ fontSize: "16px", color: "#1B6A68" }}>Paket Soal Tryout beserta jawaban</p>
                      </div>
                    </div>
                    <div className="row ms-1">
                      <div className="col-md-2">
                        <img style={{ width: "130%" }} className="img2" src={process.env.PUBLIC_URL + '/icon/check-gratis.png'} alt="" />
                      </div>
                      <div className="col-md-10 mt-2">
                        <p style={{ fontSize: "16px", color: "#1B6A68" }}>Penilaian IRT / CAT</p>
                      </div>
                    </div>

                    <div className="row " style={{ marginTop:"195px" }}>
                    <Button
                      link="http://localhost:3000/"
                      text="Beli Paket"
                      color="#1B6A68"
                    />
                    </div>
                  </div>
                </div>
              </div>

              <div className="col-md-4">
                <div className="card shadow">
                  <div className="card-header mb-2" style={{ backgroundColor: "#EBAB51" }} >
                    <p className='text-center text-white' style={{fontSize: "32px"}}>Diskon up tu 90%</p>
                  </div>
                  <div className="card-body p-4"  style={{ height: "496px" }}> 
                    <div className="row">
                      <div className="col-md-3">
                        <img style={{ width: "130%" }} className="img2" src={process.env.PUBLIC_URL + '/icon/paket-cerdas.png'} alt="" />
                      </div>
                      <div className="col-md-9">
                        <div className="row ms-2 fw-bold">
                          <p style={{ fontSize: "32px", color: "#DD8100" }}>Cerdas</p>
                        </div>
                        <div className="row ms-2">
                          <p style={{ fontSize: "24px", color: "#EBAB51" }}>Rp 20.000,-</p>
                        </div>
                      </div>
                    </div>

                    <div className="row mt-4 ms-1">
                      <div className="col-md-2">
                        <img style={{ width: "130%" }} className="img2" src={process.env.PUBLIC_URL + '/icon/check-cerdas.png'} alt="" />
                      </div>
                      <div className="col-md-10 mt-2">
                        <p style={{ fontSize: "16px", color: "#DD8100" }}>Paket Soal Tryout beserta jawaban</p>
                      </div>
                    </div>
                    <div className="row ms-1">
                      <div className="col-md-2">
                        <img style={{ width: "130%" }} className="img2" src={process.env.PUBLIC_URL + '/icon/check-cerdas.png'} alt="" />
                      </div>
                      <div className="col-md-10 mt-2">
                        <p style={{ fontSize: "16px", color: "#DD8100" }}>Penilaian IRT / CAT</p>
                      </div>
                    </div>
                    <div className="row ms-1">
                      <div className="col-md-2">
                        <img style={{ width: "130%" }} className="img2" src={process.env.PUBLIC_URL + '/icon/check-cerdas.png'} alt="" />
                      </div>
                      <div className="col-md-10 mt-2">
                        <p style={{ fontSize: "16px", color: "#DD8100" }}>Pembahasan soal</p>
                      </div>
                    </div>
                    <div className="row ms-1">
                      <div className="col-md-2">
                        <img style={{ width: "130%" }} className="img2" src={process.env.PUBLIC_URL + '/icon/check-cerdas.png'} alt="" />
                      </div>
                      <div className="col-md-10 mt-2 mb-5">
                        <p style={{ fontSize: "16px", color: "#DD8100" }}>Terdapat waktu pengerjaan seperti Tryout sungguhan</p>
                      </div>
                    </div>

                    <div className="row mt-5">
                    <Button
                      link="http://localhost:3000/"
                      text="Beli Paket"
                      color="#EBAB51"
                    />
                    </div>
                  </div>
                </div>
              </div>

              <div className="col-md-4">
                <div className="card shadow">
                  <div className="card-header mb-2" style={{ backgroundColor: "#B43D43" }} >
                    <p className='text-center text-white' style={{fontSize: "32px"}}>Diskon up tu 70%</p>
                  </div>
                  <div className="card-body p-4"  style={{ height: "496px" }}> 
                    <div className="row">
                      <div className="col-md-3">
                        <img style={{ width: "130%" }} className="img2" src={process.env.PUBLIC_URL + '/icon/paket-super.png'} alt="" />
                      </div>
                      <div className="col-md-9">
                        <div className="row ms-2 fw-bold">
                          <p style={{ fontSize: "32px", color: "#951B21" }}>super</p>
                        </div>
                        <div className="row ms-2">
                          <p style={{ fontSize: "24px", color: "#B43D43" }}>Rp 60.000,-</p>
                        </div>
                      </div>
                    </div>

                    <div className="row mt-4 ms-1">
                      <div className="col-md-2">
                        <img style={{ width: "130%" }} className="img2" src={process.env.PUBLIC_URL + '/icon/check-super.png'} alt="" />
                      </div>
                      <div className="col-md-10 mt-2">
                        <p style={{ fontSize: "16px", color: "#951B21" }}>Paket Soal Tryout beserta jawaban</p>
                      </div>
                    </div>
                    <div className="row ms-1">
                      <div className="col-md-2">
                        <img style={{ width: "130%" }} className="img2" src={process.env.PUBLIC_URL + '/icon/check-super.png'} alt="" />
                      </div>
                      <div className="col-md-10 mt-2">
                        <p style={{ fontSize: "16px", color: "#951B21" }}>Penilaian IRT / CAT</p>
                      </div>
                    </div>
                    <div className="row ms-1">
                      <div className="col-md-2">
                        <img style={{ width: "130%" }} className="img2" src={process.env.PUBLIC_URL + '/icon/check-super.png'} alt="" />
                      </div>
                      <div className="col-md-10 mt-2">
                        <p style={{ fontSize: "16px", color: "#951B21" }}>Pembahasan Soal</p>
                      </div>
                    </div>
                    <div className="row ms-1">
                      <div className="col-md-2">
                        <img style={{ width: "130%" }} className="img2" src={process.env.PUBLIC_URL + '/icon/check-super.png'} alt="" />
                      </div>
                      <div className="col-md-10 mt-2 mb-5">
                        <p style={{ fontSize: "16px", color: "#951B21" }}>Terdapat waktu pengerjaan seperti Tryout sungguhan</p>
                      </div>
                    </div>

                    <div className="row mt-5" style={{  }}>
                    <Button
                      link="http://localhost:3000/"
                      text="Beli Paket"
                      color="#B43D43"
                    />
                    </div>
                  </div>
                </div>
              </div>

            </div>

            <div id="ulasan">
              <div className="row justify-content-center mt-5">
                <div className="col-md-5  mt-5">
                  <p className=' tittle-ijo '>Begini ulasan dari <p className='tittle-oren'>edufren</p> </p>
                </div>
              </div>

              <div className="row justify-content-center mt-5">
                <div className="col-md-4">
                  <div className="card shadow">
                    <div className="card-body">
                      <div className="row justify-content-center">
                        <img style={{ width: "28%" }} className="img2" src={process.env.PUBLIC_URL + '/icon/person-circle.png'} alt="" />
                      </div>
                      <div className="row justify-content-center mt-3">
                        <img style={{ width: "40%" }} className="img2" src={process.env.PUBLIC_URL + '/icon/5stars.png'} alt="" />
                      </div>
                      <div className="row justify-content-center mb-3">
                        <p className='nama fw-bold text-center' style={{ fontSize: "20px", color:"#20A5A2" }}> Handoyo Dwi Prasetyo</p>
                      </div>
                      <div className="row justify-content-center px-2 mb-3">
                        <p className='nama text-center' style={{ fontSize: "12px", color:"#20A5A2" }}>Paket tryout super sangat worth it, karena kita mendapatkan pembahasan dan penjelasan dari mentor, sehingga memudahkan saya dalam memahami soal</p>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="col-md-4">
                  <div className="card shadow">
                    <div className="card-body">
                      <div className="row justify-content-center">
                        <img style={{ width: "28%" }} className="img2" src={process.env.PUBLIC_URL + '/icon/person-circle.png'} alt="" />
                      </div>
                      <div className="row justify-content-center mt-3">
                        <img style={{ width: "40%" }} className="img2" src={process.env.PUBLIC_URL + '/icon/5stars.png'} alt="" />
                      </div>
                      <div className="row justify-content-center mb-3">
                        <p className='nama fw-bold text-center' style={{ fontSize: "20px", color:"#20A5A2" }}> Handoyo Dwi Prasetyo</p>
                      </div>
                      <div className="row justify-content-center px-2 mb-3">
                        <p className='nama text-center' style={{ fontSize: "12px", color:"#20A5A2" }}>Paket tryout super sangat worth it, karena kita mendapatkan pembahasan dan penjelasan dari mentor, sehingga memudahkan saya dalam memahami soal</p>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="col-md-4">
                  <div className="card shadow">
                    <div className="card-body">
                      <div className="row justify-content-center">
                        <img style={{ width: "28%" }} className="img2" src={process.env.PUBLIC_URL + '/icon/person-circle.png'} alt="" />
                      </div>
                      <div className="row justify-content-center mt-3">
                        <img style={{ width: "40%" }} className="img2" src={process.env.PUBLIC_URL + '/icon/5stars.png'} alt="" />
                      </div>
                      <div className="row justify-content-center mb-3">
                        <p className='nama fw-bold text-center' style={{ fontSize: "20px", color:"#20A5A2" }}> Handoyo Dwi Prasetyo</p>
                      </div>
                      <div className="row justify-content-center px-2 mb-3">
                        <p className='nama text-center' style={{ fontSize: "12px", color:"#20A5A2" }}>Paket tryout super sangat worth it, karena kita mendapatkan pembahasan dan penjelasan dari mentor, sehingga memudahkan saya dalam memahami soal</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              <div className="row justify-content-center mt-5">
                  <div className="col-1">
                  <img style={{ width: "130%" }} className="img2" src={process.env.PUBLIC_URL + '/icon/arahkiri.png'} alt="" />
                  </div>
                  <div className="col-1">
                  <img style={{ width: "130%" }} className="img2" src={process.env.PUBLIC_URL + '/icon/arahkanan.png'} alt="" />
                  </div>
              </div>
            </div>
          </div>
        </section>

        {/* faq */}
        <section id="faq">
          <div className="container">
            <div className=" row justify-content-center my-5">
              <div className="col-md-6">
              <p className=' tittle-ijo '>Nihh pertanyaan yang sering<p className='tittle-oren'> diajukan</p> </p>
              </div>
            </div>
            <div className="row justify-content-center mb-3">
              <div className="col-md-10">
                <div className="card shadow" style={{ borderRadius:"20px" }}>
                  <div className="card-body">
                    <div className="row justify-justify-justify-content-end mt-2">
                      <div className="col-md-11 px-5">
                        <p className='fw-bold' style={{ fontSize: "24px", color:"#20A5A2" }}>1. Apa sih bedanya Tryout Gratis dengan Berbayar</p>
                      </div>
                      <div className="col-md-1">
                      <img style={{ width: "70%" }} className="img2" src={process.env.PUBLIC_URL + '/icon/minus.png'} alt="" />
                      </div>
                    </div>
                    <div className="row">
                      <div className="col-md-11 px-5">
                        <p className='nama px-4' style={{ fontSize: "18px", color:"#EBAB51" }}>Tryout Gratis dapat di akses oleh semua user, sedangkan Tryout berbayar hanya bisa di akses oleh pengguna berbayar saja, dan cuma pengguna berbayar saja yang dapat mengakses pembahasan soal</p>
                      </div>
                    </div>
                  </div>
                  
                </div>
              </div>
            </div>
            <div className="row justify-content-center mb-3">
              <div className="col-md-10">
                <div className="card shadow" style={{ borderRadius:"20px" }}>
                  <div className="card-body">
                    <div className="row justify-justify-justify-content-end mt-2">
                      <div className="col-md-11 px-5">
                        <p className='fw-bold' style={{ fontSize: "24px", color:"#20A5A2" }}>2. Gimana sih cara ikutan Tryout online ?</p>
                      </div>
                      <div className="col-md-1">
                      <img style={{ width: "70%" }} className="img2" src={process.env.PUBLIC_URL + '/icon/plus.png'} alt="" />
                      </div>
                    </div>
                  </div>
                  
                </div>
              </div>
            </div>
            <div className="row justify-content-center mb-3">
              <div className="col-md-10">
                <div className="card shadow" style={{ borderRadius:"20px" }}>
                  <div className="card-body">
                    <div className="row justify-justify-justify-content-end mt-2">
                      <div className="col-md-11 px-5">
                        <p className='fw-bold' style={{ fontSize: "24px", color:"#20A5A2" }}>3. Lewat apa sih kalau mau ngerjain Tryout online ini ?</p>
                      </div>
                      <div className="col-md-1">
                      <img style={{ width: "70%" }} className="img2" src={process.env.PUBLIC_URL + '/icon/plus.png'} alt="" />
                      </div>
                    </div>
                  </div>
                  
                </div>
              </div>
            </div>
            <div className="row justify-content-center mb-3">
              <div className="col-md-10">
                <div className="card shadow" style={{ borderRadius:"20px" }}>
                  <div className="card-body">
                    <div className="row justify-justify-justify-content-end mt-2">
                      <div className="col-md-11 px-5">
                        <p className='fw-bold' style={{ fontSize: "24px", color:"#20A5A2" }}>4. Soal Tryout bisa di download gak sih ?</p>
                      </div>
                      <div className="col-md-1">
                      <img style={{ width: "70%" }} className="img2" src={process.env.PUBLIC_URL + '/icon/plus.png'} alt="" />
                      </div>
                    </div>
                  </div>
                  
                </div>
              </div>
            </div>
            <div className="row justify-content-center mb-3">
              <div className="col-md-10">
                <div className="card shadow" style={{ borderRadius:"20px" }}>
                  <div className="card-body">
                    <div className="row justify-justify-justify-content-end mt-2">
                      <div className="col-md-11 px-5">
                        <p className='fw-bold' style={{ fontSize: "24px", color:"#20A5A2" }}>5. Apakah hanya bisa ikutan Tryout online sesuai jadwal ?</p>
                      </div>
                      <div className="col-md-1">
                      <img style={{ width: "70%" }} className="img2" src={process.env.PUBLIC_URL + '/icon/plus.png'} alt="" />
                      </div>
                    </div>
                  </div>
                  
                </div>
              </div>
            </div>
            <div className="row justify-content-center mb-3">
              <div className="col-md-10">
                <div className="card shadow" style={{ borderRadius:"20px" }}>
                  <div className="card-body">
                    <div className="row justify-justify-justify-content-end mt-2">
                      <div className="col-md-11 px-5">
                        <p className='fw-bold' style={{ fontSize: "24px", color:"#20A5A2" }}>6. Bisa gak sih ngerjain Tryout online yang sudah terlewat ?</p>
                      </div>
                      <div className="col-md-1">
                      <img style={{ width: "70%" }} className="img2" src={process.env.PUBLIC_URL + '/icon/plus.png'} alt="" />
                      </div>
                    </div>
                  </div>
                  
                </div>
              </div>
            </div>
            <div className="row justify-content-center mb-3">
              <div className="col-md-10">
                <div className="card shadow" style={{ borderRadius:"20px" }}>
                  <div className="card-body">
                    <div className="row justify-justify-justify-content-end mt-2">
                      <div className="col-md-11 px-5">
                        <p className='fw-bold' style={{ fontSize: "24px", color:"#20A5A2" }}>7. Bisa gak sih ngerjain ulang Tryout online ?</p>
                      </div>
                      <div className="col-md-1">
                      <img style={{ width: "70%" }} className="img2" src={process.env.PUBLIC_URL + '/icon/plus.png'} alt="" />
                      </div>
                    </div>
                  </div>
                  
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* footer */}
        <Footer/>
      </div>
    </div>
  );
}

export default index;