import React from 'react';
import Navbar from '../../components/Navbar';
import Button from '../../components/Button';
import Footer from '../../components/Footer';

import './index.css';
function index(props) {
  return (
    <div id='Preview'>
        {/* header */}
        <section id="">
          <div id="navbar">
            <Navbar/>
          </div>
        </section>

        {/* tittle */}
        <section id="tittle">
          <div className="container mt-5 p-5  shadow-sm" style={{ borderRadius:"20px", backgroundColor:"#CFE6E7" }}>
            <div className="row justify-content-center">
              <div className="col-8">
                <div className="gambar" >

                </div>
              </div>
              <div className="col-4 p-3">
                <div className="row p-3">
                  <p className='fw-bold my-2 mt-5' style={{ fontSize:"42px", color:"#1B6A68" }}>Paket UTBK #1  Sukses Masuk PTN </p>
                  <p className='fw-bold my-2' style={{ fontSize:"24px", color:"#1B6A68" }}>21 Januari - 24 Januari 2022 </p>
                </div>
                <div className="row">
                  <p  className='fw-bold my-2 p-3' style={{ fontSize:"24px", backgroundColor: "#F7DDB9", borderRadius: "20px", color:"#DD8100" }}><img style={{ width: "15%", borderRadius:"50%", padding: "1%" }} className="img2 mx-3" src={process.env.PUBLIC_URL + '/icon/clock.png'} alt="" />1 Hari, 23 Jam, 54 Menit</p>
                </div>
              </div>
            </div>
           
          </div>
        </section>

        {/* content */}
        <section id="content">
          <div className="container mt-5">
            <div className="row">
              <div className="col-8 mb-5">
                <div className="row ">
                  <div className="col-2 text-center me-3">
                    <Button
                          link="http://localhost:3000/"
                          text="Deskripsi"
                          color="#1B6A68"
                        />
                  </div>
                  <div className="col-3 me-2 text-center">
                    <Button
                          link="http://localhost:3000/"
                          text="Detail Soal"
                          color="#1B6A68"
                        />
                  </div>
                  <div className="col-2 me-4 text-center" >
                    <Button
                          link="http://localhost:3000/"
                          text="riwayat"
                          color="#1B6A68"
                        />
                  </div>
                  <div className="col-2 text-center ">
                    <Button
                          link="http://localhost:3000/"
                          text="Ulasan"
                          color="#1B6A68"
                        />
                  </div>
                  
                </div>
                <div className="row">
                  <p className='fw-bold my-2 mt-5' style={{ fontSize:"38px", color:"#1B6A68" }}>Deskripsi</p>
                  <p className='my-2' style={{ fontSize:"26px", color:"#1B6A68" }}>Pada paket tryout UTBK #1 Sukses Masuk PTN terdapat macam macam jenis soal antara lain yaitu soal HOTS atau Higher Order Thinking Skills diartikan sebagai kemampuan seseorang untuk berpikir tingkat tinggi dan juga terdapat prediksi jenis jenis soal yang akan muncul di UTBK 2022 </p>
                </div>
                <div className="row mt-5">
                  <p className='fw-bold my-2 mt-5' style={{ fontSize:"38px", color:"#1B6A68" }}>Keuntungan yang di peroleh</p>
                </div>
                <div className="row mt-3">
                  <div className="col-6">
                    <div className="row">
                      <div className="col-3">
                        <img style={{ width: "100%", borderRadius:"50%", padding: "1%" }} className="img2" src={process.env.PUBLIC_URL + '/icon/check-circle.png'} alt="" /> 
                      </div>
                      <div className="col-9">
                        <p  className=' my-2' style={{ fontSize:"24px", color:"#1B6A68" }}>Paket Soal Tryout beserta jawaban</p>
                      </div>
                    </div>
                    <div className="row">
                      <div className="col-3">
                        <img style={{ width: "100%", borderRadius:"50%", padding: "1%" }} className="img2" src={process.env.PUBLIC_URL + '/icon/check-circle.png'} alt="" /> 
                      </div>
                      <div className="col-9">
                        <p  className='pt-3  my-2' style={{ fontSize:"24px", color:"#1B6A68" }}>Penilaian IRT</p>
                      </div>
                    </div>
                    <div className="row">
                      <div className="col-3">
                        <img style={{ width: "100%", borderRadius:"50%", padding: "1%" }} className="img2" src={process.env.PUBLIC_URL + '/icon/check-circle.png'} alt="" /> 
                      </div>
                      <div className="col-9">
                        <p  className='pt-3  my-2' style={{ fontSize:"24px", color:"#1B6A68" }}>Pembahasan Soal</p>
                      </div>
                    </div>
                    <div className="row">
                      <div className="col-3">
                        <img style={{ width: "100%", borderRadius:"50%", padding: "1%" }} className="img2" src={process.env.PUBLIC_URL + '/icon/check-circle.png'} alt="" /> 
                      </div>
                      <div className="col-9">
                        <p  className='pt-3 my-2' style={{ fontSize:"24px", color:"#1B6A68" }}>Timer seperti real Tryout</p>
                      </div>
                    </div>
                  </div>
                  <div className="col-6">
                    <div className="row">
                      <div className="col-3">
                        <img style={{ width: "100%", borderRadius:"50%", padding: "1%" }} className="img2" src={process.env.PUBLIC_URL + '/icon/check-circle.png'} alt="" /> 
                      </div>
                      <div className="col-9">
                        <p  className='pt-3 my-2' style={{ fontSize:"24px", color:"#1B6A68" }}>Pemeringkatan National</p>
                      </div>
                    </div>
                    <div className="row">
                      <div className="col-3">
                        <img style={{ width: "100%", borderRadius:"50%", padding: "1%" }} className="img2" src={process.env.PUBLIC_URL + '/icon/check-circle.png'} alt="" /> 
                      </div>
                      <div className="col-9">
                        <p  className='  my-2' style={{ fontSize:"24px", color:"#1B6A68" }}>Zoom pembahasan bersama mentor</p>
                      </div>
                    </div>
                    <div className="row">
                      <div className="col-3">
                        <img style={{ width: "100%", borderRadius:"50%", padding: "1%" }} className="img2" src={process.env.PUBLIC_URL + '/icon/check-circle.png'} alt="" /> 
                      </div>
                      <div className="col-9">
                        <p  className='my-2' style={{ fontSize:"24px", color:"#1B6A68" }}>Rasionalisasi perguruan tinggi impian</p>
                      </div>
                    </div>
                  </div>
                </div>
                
                <div className="row">
                  <p className='fw-bold my-2 mt-5' style={{ fontSize:"38px", color:"#1B6A68" }}>Mentor</p>
                  <div className="col-8">
                    <div className="card p-3 mt-3 shadow-sm" style={{ borderRadius:"100px 20px 20px 100px", backgroundColor:"#CFE6E7" }}>
                      <div className="row">
                        <div className="col-3 mx-3">
                          <img style={{ width: "120%", borderRadius:"50%", padding: "1%" }} className="img2" src={process.env.PUBLIC_URL + '/icon/person-circle.png'} alt="" /> 
                        </div>
                        <div className="col-8">
                          <p className='fw-bold my-2' style={{ fontSize:"38px", color:"#1B6A68" }}>Handoyo Dwi P</p>
                          <p className='' style={{ fontSize:"26px", color:"#1B6A68" }}>UPN “Veteran” Yogyakarta</p>

                        </div>

                      </div>
                    </div>
                  </div>
                </div>
              </div>


              <div className="col-4">
                <div className="card shadow-sm p-4" style={{ backgroundColor:"#ffffff", borderRadius:"20px" }}>
                  <div className="row pt-2 px-3 " style={{ backgroundColor:"#CFE6E7", borderRadius:"100px" }}>
                    <div className="col-6">
                      <p className='fw-bold' style={{ color:"#1B6A68", fontSize:"20px" }}>Gelombang 1</p>
                    </div>
                    <div className="col-6">
                      <p className='text-end fw-bold' style={{ color:"#EBAB51", fontSize:"20px" }}>21 Januari</p>
                    </div>
                  </div>
                  <div className="row pt-2 px-3 my-3" style={{ backgroundColor:"#4DB7B5", borderRadius:"100px" }}>
                    <div className="col-6">
                      <p className='fw-bold' style={{ color:"#ffffff", fontSize:"20px" }}>Gelombang 2</p>
                    </div>
                    <div className="col-6">
                      <p className='text-end fw-bold' style={{ color:"#EBAB51", fontSize:"20px" }}>22 Januari</p>
                    </div>
                  </div>
                  <div className="row pt-2 px-3 my-3" style={{ backgroundColor:"#CFE6E7", borderRadius:"100px" }}>
                    <div className="col-6">
                      <p className='fw-bold' style={{ color:"#1B6A68", fontSize:"20px" }}>Gelombang 3</p>
                    </div>
                    <div className="col-6">
                      <p className='text-end fw-bold' style={{ color:"#EBAB51", fontSize:"20px" }}>23 Januari</p>
                    </div>
                  </div>
                  <div className="row pt-2 px-3 my-3" style={{ backgroundColor:"#CFE6E7", borderRadius:"100px" }}>
                    <div className="col-6">
                      <p className='fw-bold' style={{ color:"#1B6A68", fontSize:"20px" }}>Gelombang 4</p>
                    </div>
                    <div className="col-6">
                      <p className='text-end fw-bold' style={{ color:"#EBAB51", fontSize:"20px" }}>24 Januari</p>
                    </div>
                  </div>
                  <div className="row pt-2 px-3 mt-3" style={{ backgroundColor:"#20A5A2", borderRadius:"100px" }}>
                      <p className='fw-bold text-center' style={{ color:"#ffffff", fontSize:"20px" }}>Gabung Tryout</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
          
        </section>
        

        
        {/* footer */}
        <Footer/>
    </div>
  );
}

export default index;