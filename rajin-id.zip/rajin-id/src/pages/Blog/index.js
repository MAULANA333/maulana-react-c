import React from 'react';
import Navbar from '../../components/Navbar';
import Button from '../../components/Button';
import Footer from '../../components/Footer';

import './index.css';
function index(props) {
  return (
    <div id='blog'>
        {/* header */}
        <section id="header">
          <div id="navbar">
            <Navbar/>
          </div>
          <div className="container">
            <div className="row justify-content-center">
              <div className="col-md-7">
                <div id="header-tittle" >
                  <h1 className='text-center'>Siapa Tau Cocok</h1>
                  <div className="row justify-content-center">
                    <div className="col-md-9">
                      <p className='text-center' style={{ fontSize:"26px" }}>Informasi yang mungkin bermanfaat untuk meningkatkan pengetahuanmu </p>
                    </div>
                  </div>
                  
                </div>
              </div>
             
            </div>
            
          </div>

          {/* <img src={require('../../../public/img/wave.svg').default} alt='mySvgImage' /> */}
          {/* <img alt="Clock" src={require('../../../public/img/wave.svg')}/> */}

        </section>

        {/* tombol */}
        <section id='tombol' style={{ backgroundColor:"#E5E5E5" }}>
          <div className="container" >
            <div className="row justify-content-center">
              <div className="col-md-2">
                <div className="  text-center p-2 rounded-pill" style={{ marginTop:"-20px", backgroundColor:"#e5e5e5" }}>
                  <Button
                    link="http://localhost:3000/"
                    text="Event"
                    color="#1B6A68"
                  />
                </div>
              </div>
              <div className="col-md-2">
                <div className=" text-center p-2 rounded-pill" style={{ marginTop:"-20px", backgroundColor:"#e5e5e5" }}>
                  <Button
                    link="http://localhost:3000/"
                    text="Artikel"
                    color="#1B6A68"
                  />
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* blog */}
        <section id="bloglist" className='mt-5' style={{ backgroundColor:"#E5E5E5" }}>
          <div className="container">
            <div className="row ">
              <div className="col-md-4 my-3">
                <div className="card shadow p-2" style={{ borderRadius:"20px" }}>
                  <div className="card-body">
                    <div className="row">
                      <div className="" style={{ height:"204px", backgroundColor:"#C4C4C4", borderRadius:"20px" }}></div>
                    </div>
                    <div className="row mt-2">
                      <p className='fw-bold' style={{ fontSize:"26px", color:"#1B6A68" }}>Ganti Cara Persiapan UTBK di Eduton UTBK Fest</p>
                    </div>
                    <div className="row my-2">
                      <div className="col-md-7">
                        <p className='fw-bold' style={{ fontSize:"16px", color:"#1B6A68" }}>Handoyo Dwi Prasetyo</p>
                      </div>
                      <div className="col-md-5">
                        <p className='text-end' style={{ fontSize:"16px", color:"#DD8100" }}>21 Januari 2022</p>
                      </div>
                    </div>
                    <div className="row">
                      <p className='' style={{ fontSize:"16px", color:"#1B6A68" }}>Eduton UTBK Fest adalah event online yang dibikin buat elo para pejuang UTBK. Ada 24 live seminar yang bisa elo ikutin, belasan universitas, dan puluhan speakers yang bakal bantu persiapan UTBK elo! Apa aja acaranya? Saatnya atur…</p>
                    </div>
                    <div className="row mt-2 mb-4">
                      <p className='fw-bold' style={{ fontSize:"16px", color:"#1B6A68" }}>Baca Selengkapnya..</p>
                    </div>
                  </div>
                </div>
              </div>
              <div className="col-md-4 my-3">
                <div className="card shadow p-2" style={{ borderRadius:"20px" }}>
                  <div className="card-body">
                    <div className="row">
                      <div className="" style={{ height:"204px", backgroundColor:"#C4C4C4", borderRadius:"20px" }}></div>
                    </div>
                    <div className="row mt-2">
                      <p className='fw-bold' style={{ fontSize:"26px", color:"#1B6A68" }}>Ganti Cara Persiapan UTBK di Eduton UTBK Fest</p>
                    </div>
                    <div className="row my-2">
                      <div className="col-md-7">
                        <p className='fw-bold' style={{ fontSize:"16px", color:"#1B6A68" }}>Handoyo Dwi Prasetyo</p>
                      </div>
                      <div className="col-md-5">
                        <p className='text-end' style={{ fontSize:"16px", color:"#DD8100" }}>21 Januari 2022</p>
                      </div>
                    </div>
                    <div className="row">
                      <p className='' style={{ fontSize:"16px", color:"#1B6A68" }}>Eduton UTBK Fest adalah event online yang dibikin buat elo para pejuang UTBK. Ada 24 live seminar yang bisa elo ikutin, belasan universitas, dan puluhan speakers yang bakal bantu persiapan UTBK elo! Apa aja acaranya? Saatnya atur…</p>
                    </div>
                    <div className="row mt-2 mb-4">
                      <p className='fw-bold' style={{ fontSize:"16px", color:"#1B6A68" }}>Baca Selengkapnya..</p>
                    </div>
                  </div>
                </div>
              </div>
              <div className="col-md-4 my-3">
                <div className="card shadow p-2" style={{ borderRadius:"20px" }}>
                  <div className="card-body">
                    <div className="row">
                      <div className="" style={{ height:"204px", backgroundColor:"#C4C4C4", borderRadius:"20px" }}></div>
                    </div>
                    <div className="row mt-2">
                      <p className='fw-bold' style={{ fontSize:"26px", color:"#1B6A68" }}>Ganti Cara Persiapan UTBK di Eduton UTBK Fest</p>
                    </div>
                    <div className="row my-2">
                      <div className="col-md-7">
                        <p className='fw-bold' style={{ fontSize:"16px", color:"#1B6A68" }}>Handoyo Dwi Prasetyo</p>
                      </div>
                      <div className="col-md-5">
                        <p className='text-end' style={{ fontSize:"16px", color:"#DD8100" }}>21 Januari 2022</p>
                      </div>
                    </div>
                    <div className="row">
                      <p className='' style={{ fontSize:"16px", color:"#1B6A68" }}>Eduton UTBK Fest adalah event online yang dibikin buat elo para pejuang UTBK. Ada 24 live seminar yang bisa elo ikutin, belasan universitas, dan puluhan speakers yang bakal bantu persiapan UTBK elo! Apa aja acaranya? Saatnya atur…</p>
                    </div>
                    <div className="row mt-2 mb-4">
                      <p className='fw-bold' style={{ fontSize:"16px", color:"#1B6A68" }}>Baca Selengkapnya..</p>
                    </div>
                  </div>
                </div>
              </div>
              <div className="col-md-4 my-3">
                <div className="card shadow p-2" style={{ borderRadius:"20px" }}>
                  <div className="card-body">
                    <div className="row">
                      <div className="" style={{ height:"204px", backgroundColor:"#C4C4C4", borderRadius:"20px" }}></div>
                    </div>
                    <div className="row mt-2">
                      <p className='fw-bold' style={{ fontSize:"26px", color:"#1B6A68" }}>Ganti Cara Persiapan UTBK di Eduton UTBK Fest</p>
                    </div>
                    <div className="row my-2">
                      <div className="col-md-7">
                        <p className='fw-bold' style={{ fontSize:"16px", color:"#1B6A68" }}>Handoyo Dwi Prasetyo</p>
                      </div>
                      <div className="col-md-5">
                        <p className='text-end' style={{ fontSize:"16px", color:"#DD8100" }}>21 Januari 2022</p>
                      </div>
                    </div>
                    <div className="row">
                      <p className='' style={{ fontSize:"16px", color:"#1B6A68" }}>Eduton UTBK Fest adalah event online yang dibikin buat elo para pejuang UTBK. Ada 24 live seminar yang bisa elo ikutin, belasan universitas, dan puluhan speakers yang bakal bantu persiapan UTBK elo! Apa aja acaranya? Saatnya atur…</p>
                    </div>
                    <div className="row mt-2 mb-4">
                      <p className='fw-bold' style={{ fontSize:"16px", color:"#1B6A68" }}>Baca Selengkapnya..</p>
                    </div>
                  </div>
                </div>
              </div>
              <div className="col-md-4 my-3">
                <div className="card shadow p-2" style={{ borderRadius:"20px" }}>
                  <div className="card-body">
                    <div className="row">
                      <div className="" style={{ height:"204px", backgroundColor:"#C4C4C4", borderRadius:"20px" }}></div>
                    </div>
                    <div className="row mt-2">
                      <p className='fw-bold' style={{ fontSize:"26px", color:"#1B6A68" }}>Ganti Cara Persiapan UTBK di Eduton UTBK Fest</p>
                    </div>
                    <div className="row my-2">
                      <div className="col-md-7">
                        <p className='fw-bold' style={{ fontSize:"16px", color:"#1B6A68" }}>Handoyo Dwi Prasetyo</p>
                      </div>
                      <div className="col-md-5">
                        <p className='text-end' style={{ fontSize:"16px", color:"#DD8100" }}>21 Januari 2022</p>
                      </div>
                    </div>
                    <div className="row">
                      <p className='' style={{ fontSize:"16px", color:"#1B6A68" }}>Eduton UTBK Fest adalah event online yang dibikin buat elo para pejuang UTBK. Ada 24 live seminar yang bisa elo ikutin, belasan universitas, dan puluhan speakers yang bakal bantu persiapan UTBK elo! Apa aja acaranya? Saatnya atur…</p>
                    </div>
                    <div className="row mt-2 mb-4">
                      <p className='fw-bold' style={{ fontSize:"16px", color:"#1B6A68" }}>Baca Selengkapnya..</p>
                    </div>
                  </div>
                </div>
              </div>
              <div className="col-md-4 my-3">
                <div className="card shadow p-2" style={{ borderRadius:"20px" }}>
                  <div className="card-body">
                    <div className="row">
                      <div className="" style={{ height:"204px", backgroundColor:"#C4C4C4", borderRadius:"20px" }}></div>
                    </div>
                    <div className="row mt-2">
                      <p className='fw-bold' style={{ fontSize:"26px", color:"#1B6A68" }}>Ganti Cara Persiapan UTBK di Eduton UTBK Fest</p>
                    </div>
                    <div className="row my-2">
                      <div className="col-md-7">
                        <p className='fw-bold' style={{ fontSize:"16px", color:"#1B6A68" }}>Handoyo Dwi Prasetyo</p>
                      </div>
                      <div className="col-md-5">
                        <p className='text-end' style={{ fontSize:"16px", color:"#DD8100" }}>21 Januari 2022</p>
                      </div>
                    </div>
                    <div className="row">
                      <p className='' style={{ fontSize:"16px", color:"#1B6A68" }}>Eduton UTBK Fest adalah event online yang dibikin buat elo para pejuang UTBK. Ada 24 live seminar yang bisa elo ikutin, belasan universitas, dan puluhan speakers yang bakal bantu persiapan UTBK elo! Apa aja acaranya? Saatnya atur…</p>
                    </div>
                    <div className="row mt-2 mb-4">
                      <p className='fw-bold' style={{ fontSize:"16px", color:"#1B6A68" }}>Baca Selengkapnya..</p>
                    </div>
                  </div>
                </div>
              </div>
              <div className="col-md-4 my-3">
                <div className="card shadow p-2" style={{ borderRadius:"20px" }}>
                  <div className="card-body">
                    <div className="row">
                      <div className="" style={{ height:"204px", backgroundColor:"#C4C4C4", borderRadius:"20px" }}></div>
                    </div>
                    <div className="row mt-2">
                      <p className='fw-bold' style={{ fontSize:"26px", color:"#1B6A68" }}>Ganti Cara Persiapan UTBK di Eduton UTBK Fest</p>
                    </div>
                    <div className="row my-2">
                      <div className="col-md-7">
                        <p className='fw-bold' style={{ fontSize:"16px", color:"#1B6A68" }}>Handoyo Dwi Prasetyo</p>
                      </div>
                      <div className="col-md-5">
                        <p className='text-end' style={{ fontSize:"16px", color:"#DD8100" }}>21 Januari 2022</p>
                      </div>
                    </div>
                    <div className="row">
                      <p className='' style={{ fontSize:"16px", color:"#1B6A68" }}>Eduton UTBK Fest adalah event online yang dibikin buat elo para pejuang UTBK. Ada 24 live seminar yang bisa elo ikutin, belasan universitas, dan puluhan speakers yang bakal bantu persiapan UTBK elo! Apa aja acaranya? Saatnya atur…</p>
                    </div>
                    <div className="row mt-2 mb-4">
                      <p className='fw-bold' style={{ fontSize:"16px", color:"#1B6A68" }}>Baca Selengkapnya..</p>
                    </div>
                  </div>
                </div>
              </div>
              <div className="col-md-4 my-3">
                <div className="card shadow p-2" style={{ borderRadius:"20px" }}>
                  <div className="card-body">
                    <div className="row">
                      <div className="" style={{ height:"204px", backgroundColor:"#C4C4C4", borderRadius:"20px" }}></div>
                    </div>
                    <div className="row mt-2">
                      <p className='fw-bold' style={{ fontSize:"26px", color:"#1B6A68" }}>Ganti Cara Persiapan UTBK di Eduton UTBK Fest</p>
                    </div>
                    <div className="row my-2">
                      <div className="col-md-7">
                        <p className='fw-bold' style={{ fontSize:"16px", color:"#1B6A68" }}>Handoyo Dwi Prasetyo</p>
                      </div>
                      <div className="col-md-5">
                        <p className='text-end' style={{ fontSize:"16px", color:"#DD8100" }}>21 Januari 2022</p>
                      </div>
                    </div>
                    <div className="row">
                      <p className='' style={{ fontSize:"16px", color:"#1B6A68" }}>Eduton UTBK Fest adalah event online yang dibikin buat elo para pejuang UTBK. Ada 24 live seminar yang bisa elo ikutin, belasan universitas, dan puluhan speakers yang bakal bantu persiapan UTBK elo! Apa aja acaranya? Saatnya atur…</p>
                    </div>
                    <div className="row mt-2 mb-4">
                      <p className='fw-bold' style={{ fontSize:"16px", color:"#1B6A68" }}>Baca Selengkapnya..</p>
                    </div>
                  </div>
                </div>
              </div>
              <div className="col-md-4 my-3">
                <div className="card shadow p-2" style={{ borderRadius:"20px" }}>
                  <div className="card-body">
                    <div className="row">
                      <div className="" style={{ height:"204px", backgroundColor:"#C4C4C4", borderRadius:"20px" }}></div>
                    </div>
                    <div className="row mt-2">
                      <p className='fw-bold' style={{ fontSize:"26px", color:"#1B6A68" }}>Ganti Cara Persiapan UTBK di Eduton UTBK Fest</p>
                    </div>
                    <div className="row my-2">
                      <div className="col-md-7">
                        <p className='fw-bold' style={{ fontSize:"16px", color:"#1B6A68" }}>Handoyo Dwi Prasetyo</p>
                      </div>
                      <div className="col-md-5">
                        <p className='text-end' style={{ fontSize:"16px", color:"#DD8100" }}>21 Januari 2022</p>
                      </div>
                    </div>
                    <div className="row">
                      <p className='' style={{ fontSize:"16px", color:"#1B6A68" }}>Eduton UTBK Fest adalah event online yang dibikin buat elo para pejuang UTBK. Ada 24 live seminar yang bisa elo ikutin, belasan universitas, dan puluhan speakers yang bakal bantu persiapan UTBK elo! Apa aja acaranya? Saatnya atur…</p>
                    </div>
                    <div className="row mt-2 mb-4">
                      <p className='fw-bold' style={{ fontSize:"16px", color:"#1B6A68" }}>Baca Selengkapnya..</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div className="row my-5">
            </div>
          </div>
        </section>

        {/* footer */}
        <Footer/>
    </div>
  );
}

export default index;