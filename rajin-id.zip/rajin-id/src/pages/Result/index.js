import React from 'react';
import { NavLink } from 'react-router-dom';
import './index.css'
function index(props) {
  return (
    <div id='result'>
      {/* header */}
      <section id='header' className='shadow-lg'>
        <img className="image1" src={process.env.PUBLIC_URL + '/img/result.png'} alt="" />
        <div className="header-content" style={{ position:"absolute", width:"100%" }}>
          <div className="row justify-content-end">
            <img className="image1" style={{ width:"7%", height:"12%" }} src={process.env.PUBLIC_URL + '/icon/arahkanan.png'} alt="" />
          </div>
          <div className="row justify-content-center">
           <h1 className='text-center mt-5 fw-bold' style={{ fontSize:"60px", color:"#ffffff" }}>HASIL</h1>
          </div>
          <div className="row justify-content-center">
          <img className="image2 text-center" src={process.env.PUBLIC_URL + '/img/champ.png'} alt="" />
          <p className='fw-bold text-center ' style={{ fontSize:"48px", color:"#DD8100", zIndex:"100", marginTop:"-210px", zIndex:"10000" }}>500</p>
          </div>
          <div className="row justify-content-center">
            <div className="col-2 text-center">
              <button className="btn rounded-pill  px-5 pt-3" style={{ backgroundColor:"rgba(255, 255, 255, 0.4)" }}>
              <h1 className='fw-bold text-center ' style={{ fontSize:"24px", color:"#ffffff", zIndex:"1000" }}>TPA : 250</h1>
              </button>
            </div>
            <div className="col-2 text-center">
              <button className="btn rounded-pill  px-5 pt-3" style={{ backgroundColor:"rgba(255, 255, 255, 0.4)" }}>
              <h1 className='fw-bold text-center ' style={{ fontSize:"24px", color:"#ffffff", zIndex:"1000" }}>TPS : 250</h1>
              </button>
            </div>
          </div>
          <div className="row justify-content-center mt-5">
          <div className="col-8 text-center">
              <NavLink activeClassName="bg-danger" className="nav-link" to="/rank"> 
                  <button className="btn btnheader  " style={{ padding:"15px 210px"  }}>
                  <h1 className='fw-bold text-center ' style={{ fontSize:"24px", color:"#ffffff", zIndex:"1000" }}>Lihat Peringkat</h1>
                  </button>
              </NavLink>
            </div>
          </div>
        </div>
        
      </section>

      {/* content */}
      <section id='content'>
        <div className="container mt-5 ">
          <div className="row justify-content-center">
            <div className="col-6">
              <div className="card p-4" style={{ borderRadius:"30px", boxShadow:"0px 4px 40px #CFE6E7", backgroundColor:"#ffffff" }}>
              <div className="row">
                <img className="image1 mt-3" style={{ width:"15%" }} src={process.env.PUBLIC_URL + '/icon/mahkota.png'} alt="" />
                <p className='fw-bold' style={{ fontSize:"42px", color:"#1B6A68" }}>120/190</p>
                <div className="col-7">
                  <p className='fw-bold' style={{ fontSize:"24px", color:"#1B6A68" }}>jumlah soal yang terjawab benar</p>
                </div>
              </div>
              </div>
            </div>
            <div className="col-6">
              <div className="card p-4" style={{ borderRadius:"30px", boxShadow:"0px 4px 40px #CFE6E7", backgroundColor:"#ffffff" }}>
              <div className="row">
                <img className="image1 mt-3" style={{ width:"12%" }} src={process.env.PUBLIC_URL + '/icon/timer.png'} alt="" />
                <p className='fw-bold' style={{ fontSize:"42px", color:"#1B6A68" }}>120 Menit</p>
                <div className="col-8">
                  <p className='fw-bold' style={{ fontSize:"24px", color:"#1B6A68" }}>waktu yang dibutuhkan dalam menjawab soal</p>
                </div>
              </div>
              </div>
            </div>
          </div>

          <div className="row mt-5">
            <div className="col-6 px-4 mb-5">
              <div className="row">
                <p className='fw-bold' style={{ fontSize:"38px", color:"#20A5A2"  }}>Hasil Pengerjaan TPS</p>
              </div>
              <div className="row ">
                <div className="card py-2 px-3" style={{ backgroundColor:"#CFE6E7", borderRadius:"20px", border:"0px" }}>
                  <span className='fw-bold' style={{ fontSize:"26px", color:"#20A5A2", fontFamily:"Quicksand"  }}>Penalaran Umum</span>
                  <span className='' style={{ fontSize:"20px", color:"#20A5A2", fontFamily:"Quicksand"  }}>8/10 jawaban benar</span>
                </div>  
              </div>
              <div className="row mt-3">
                <div className="card py-2 px-3" style={{ backgroundColor:"#CFE6E7", borderRadius:"20px", border:"0px" }}>
                  <span className='fw-bold' style={{ fontSize:"26px", color:"#20A5A2", fontFamily:"Quicksand"  }}>Pengetahuan dan Pemahaman Umum</span>
                  <span className='' style={{ fontSize:"20px", color:"#20A5A2", fontFamily:"Quicksand"  }}>6/10 jawaban benar</span>
                </div>  
              </div>
              <div className="row mt-3">
                <div className="card py-2 px-3" style={{ backgroundColor:"#CFE6E7", borderRadius:"20px", border:"0px" }}>
                  <span className='fw-bold' style={{ fontSize:"26px", color:"#20A5A2", fontFamily:"Quicksand"  }}>Kemampuan memahami bacaan dan menulis</span>
                  <span className='' style={{ fontSize:"20px", color:"#20A5A2", fontFamily:"Quicksand"  }}>9/10 jawaban benar</span>
                </div>  
              </div>
              <div className="row mt-3">
                <div className="card py-2 px-3" style={{ backgroundColor:"#CFE6E7", borderRadius:"20px", border:"0px" }}>
                  <span className='fw-bold' style={{ fontSize:"26px", color:"#20A5A2", fontFamily:"Quicksand"  }}>Kemampuan Kuantitatif</span>
                  <span className='' style={{ fontSize:"20px", color:"#20A5A2", fontFamily:"Quicksand"  }}>3/10 jawaban benar</span>
                </div>  
              </div>
              <div className="row mt-3">
                <div className="card py-2 px-3" style={{ backgroundColor:"#CFE6E7", borderRadius:"20px", border:"0px" }}>
                  <span className='fw-bold' style={{ fontSize:"26px", color:"#20A5A2", fontFamily:"Quicksand"  }}>Bahasa Inggris</span>
                  <span className='' style={{ fontSize:"20px", color:"#20A5A2", fontFamily:"Quicksand"  }}>8/10 jawaban benar</span>
                </div>  
              </div>
            </div>
            <div className="col-6 px-4 ">
              <div className="row">
                <p className='fw-bold' style={{ fontSize:"38px", color:"#20A5A2"  }}>Hasil Pengerjaan TPA</p>
              </div>
              <div className="row ">
                <div className="card py-2 px-3" style={{ backgroundColor:"#CFE6E7", borderRadius:"20px", border:"0px" }}>
                  <span className='fw-bold' style={{ fontSize:"26px", color:"#20A5A2", fontFamily:"Quicksand"  }}>Matematika Saintek</span>
                  <span className='' style={{ fontSize:"20px", color:"#20A5A2", fontFamily:"Quicksand"  }}>8/10 jawaban benar</span>
                </div>  
              </div>
              <div className="row mt-3">
                <div className="card py-2 px-3" style={{ backgroundColor:"#CFE6E7", borderRadius:"20px", border:"0px" }}>
                  <span className='fw-bold' style={{ fontSize:"26px", color:"#20A5A2", fontFamily:"Quicksand"  }}>Fisika</span>
                  <span className='' style={{ fontSize:"20px", color:"#20A5A2", fontFamily:"Quicksand"  }}>6/10 jawaban benar</span>
                </div>  
              </div>
              <div className="row mt-3">
                <div className="card py-2 px-3" style={{ backgroundColor:"#CFE6E7", borderRadius:"20px", border:"0px" }}>
                  <span className='fw-bold' style={{ fontSize:"26px", color:"#20A5A2", fontFamily:"Quicksand"  }}>Kimia</span>
                  <span className='' style={{ fontSize:"20px", color:"#20A5A2", fontFamily:"Quicksand"  }}>9/10 jawaban benar</span>
                </div>  
              </div>
              <div className="row mt-3">
                <div className="card py-2 px-3" style={{ backgroundColor:"#CFE6E7", borderRadius:"20px", border:"0px" }}>
                  <span className='fw-bold' style={{ fontSize:"26px", color:"#20A5A2", fontFamily:"Quicksand"  }}>Biologi</span>
                  <span className='' style={{ fontSize:"20px", color:"#20A5A2", fontFamily:"Quicksand"  }}>3/10 jawaban benar</span>
                </div>  
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}

export default index;