import React from 'react';
import './index.css'
function index(props) {
  return (
    <div id='rank'>
        <section id='header'>
          <img className="image1" src={process.env.PUBLIC_URL + '/icon/arahkanan.png'} alt="" />
          <img className="image2" src={process.env.PUBLIC_URL + '/img/pancoran.png'} alt="" />
          <img className="image3" src={process.env.PUBLIC_URL + '/icon/mahkota-2.png'} alt="" />
          <img className="image4" src={process.env.PUBLIC_URL + '/icon/person-circle.png'} alt="" />
          <img className="image5" src={process.env.PUBLIC_URL + '/icon/person-circle.png'} alt="" />
          <p className='rank2'>2</p>
          <div className="circle2"></div>
          <img className="image6" src={process.env.PUBLIC_URL + '/icon/person-circle.png'} alt="" />
          <p className='rank3'>3</p>
          <div className="circle3"></div>
          <img className="image7" src={process.env.PUBLIC_URL + '/img/ranks.png'} alt="" />
          
          <p className='score1'>500</p>
          <p className='name1'>Handoyo Dwi Prasetyo</p>
          <p className='school1'>SMAN 1 Banyudono</p>

          <p className='score2'>500</p>
          <p className='name2'>Handoyo Dwi Prasetyo</p>
          <p className='school2'>SMAN 1 Banyudono</p>
          
          <p className='score3'>500</p>
          <p className='name3'>Handoyo Dwi Prasetyo</p>
          <p className='school3'>SMAN 1 Banyudono</p>
        </section>
      {/* header */}

      {/* content */}

      <section id='content'>
        <div className="container">
          <div className="row">
            <div className="col-12">
              <div className="mycard p-5">
                <div className="row">
                  <div className="col-10">
                    <input type="text" className='form-control rounded-pill' style={{ height:"65px", backgroundColor:"#EAEEF0", border:"0" }} />
                  </div>
                  <div className="col-2">
                    <button className='btn rounded-pill px-5 fw-bold' style={{ backgroundColor:"#4DB7B5", height:"65px", fontSize:"26px", color:"#ffffff", fontFamily:"Quicksand" }}>search</button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

    </div>
  );
}

export default index;