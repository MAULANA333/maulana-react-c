import React from 'react';
import Button from '../../components/Button';
import Navbar from '../../components/Navbar';
import Footer from '../../components/Footer';

import './index.css';

function index(props) {
  return (
    <div>
      <div id="katalog">
         {/* header */}
         <section id="header">
            <div id="navbar">
              <Navbar/>
            </div>
            <div className="container">
              <div className="row justify-content-center">
                <div className="col-md-7">
                  <div id="header-tittle" >
                    <h1 className='text-center'>Buat Pesanan</h1>
                    <div className="row justify-content-center">
                      <div className="col-md-12">
                        <p className='text-center' style={{ fontSize:"26px" }}>Bergabung menjadi Edusob dan latih pengetahuanmu</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>            
            </div>
          </section>
          
          {/* content */}
          <section id='content'>
            <div className="container">
              <div className="row">
                <div className="col-4 my-3">
                  <div className="card shadow " style={{ borderRadius:"20px" }}>
                    <div className="card-body">
                      <div className="row px-2 py-0">
                        <div className="" style={{ height:"254px", backgroundColor:"#C4C4C4", borderRadius:"20px" }}>
                          <div className="row justify-content-end">
                            <div className="col-5">
                              <p className='text-center p-2 mt-2 me-1 fw-bold' style={{ fontSize:"20px", borderRadius:"10px", backgroundColor:"#EBAB51", color:"#ffffff" }}>Diskon 60%</p>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div className="row">
                        <p className='fw-bold' style={{ fontSize:"38px", color:"black" }}>Paket UTBK 1 - Sukses masuk PTN</p>
                      </div>
                      <div className="row ">
                        <p className='text-start fw-bold' style={{ fontSize:"20px", color:"#DD8100" }}>27 Jan - 2 Feb 2021</p>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="col-8 my-3">
                  <div className="card shadow p-5" style={{ borderRadius:"20px" }}>
                    <div className="row">
                      <p className='fw-bold' style={{ fontSize:"32px", color:"#1B6A68" }}>Bonus Keuntungan</p>
                    </div>
                    <div className="row">
                      <div className="col-6">
                        <p className='' style={{ fontSize:"26px", color:"#1B6A68" }}>Waktu Akses</p>
                      </div>
                      <div className="col-6">
                        <p className='text-end fw-bold' style={{ fontSize:"26px", color:"#1B6A68" }}>Selamanya</p>
                      </div>
                    </div>
                    <div className="row">
                      <div className="col-6">
                        <p className='' style={{ fontSize:"26px", color:"#1B6A68" }}>Rekaman Hasil Tryout</p>
                      </div>
                      <div className="col-6">
                        <p className='text-end fw-bold' style={{ fontSize:"26px", color:"#1B6A68" }}>Tersedia</p>
                      </div>
                    </div>
                    <div className="row">
                      <div className="col-6">
                        <p className='' style={{ fontSize:"26px", color:"#1B6A68" }}>Konsultasi</p>
                      </div>
                      <div className="col-6">
                        <p className='text-end fw-bold' style={{ fontSize:"26px", color:"#1B6A68" }}>Tersedia</p>
                      </div>
                    </div>
                    <div className="row">
                      <div className="col-6">
                        <p className='' style={{ fontSize:"26px", color:"#1B6A68" }}>Sertifikat Tryout</p>
                      </div>
                      <div className="col-6">
                        <p className='text-end fw-bold' style={{ fontSize:"26px", color:"#1B6A68" }}>Tersedia</p>
                      </div>
                    </div>
                    <div className="row my-3">
                      <p className='fw-bold' style={{ fontSize:"32px", color:"#1B6A68" }}>Detail Pembayaran</p>
                    </div>

                    <div className="row p-1 mb-3" style={{ border:" 1px solid #20A5A2", borderRadius:"20px" }}>
                      <p  className='fw-bold my-2 p-3' style={{ fontSize:"24px", backgroundColor: "", borderRadius: "20px", color:"#1B6A68" }}><img style={{ width: "10%", borderRadius:"50%", padding: "1%" }} className="img2 mx-3" src={process.env.PUBLIC_URL + '/icon/discount-Regular.png'} alt="" />Pakai kode promo agar lebih hemat</p>

                    </div>

                    <div className="row">
                      <div className="col-6">
                        <p className='' style={{ fontSize:"26px", color:"#1B6A68" }}>Harga Normal</p>
                      </div>
                      <div className="col-6">
                        <p className='text-end' style={{ fontSize:"26px", color:"#951B21" }}>Rp. 60.000,-</p>
                      </div>
                    </div>
                    <div className="row">
                      <div className="col-6">
                        <p className='' style={{ fontSize:"26px", color:"#1B6A68" }}>Harga Paket</p>
                      </div>
                      <div className="col-6">
                        <p className='text-end ' style={{ fontSize:"26px", color:"#1B6A68" }}>Rp. 20.000,-</p>
                      </div>
                    </div>
                    <div className="row">
                      <div className="col-6">
                        <p className='' style={{ fontSize:"26px", color:"#1B6A68" }}>Kode Promo</p>
                      </div>
                      <div className="col-6">
                        <p className='text-end' style={{ fontSize:"26px", color:"#20A5A2" }}>- Rp. 40.000,-</p>
                      </div>
                    </div>
                    <div className="row">
                      <div className="col-6">
                        <p className='' style={{ fontSize:"26px", color:"#1B6A68" }}>Kode Unik</p>
                      </div>
                      <div className="col-6">
                        <p className='text-end' style={{ fontSize:"26px", color:"#1B6A68" }}>- Rp. 234,-</p>
                      </div>
                    </div>
                    <div className="row mb-5">
                      <div className="col-6">
                        <p className='' style={{ fontSize:"26px", color:"#1B6A68" }}>Total Transfer</p>
                      </div>
                      <div className="col-6">
                        <p className='text-end fw-bold' style={{ fontSize:"26px", color:"#1B6A68" }}>Rp. 19.766,-</p>
                      </div>
                    </div>

                    <div className="row pt-2 mb-5"  style={{ backgroundColor:"#20A5A2", borderRadius:"20px" }}>
                      <p className='text-center fw-bold' style={{ backgroundColor:"", fontSize:"32px", color:"#ffffff" }}>Buat Pesanan</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </section>
          {/* footer */}
          <Footer/>
      </div>
    </div>
  );
}

export default index;