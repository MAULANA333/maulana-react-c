import React from 'react';
import Navbar from '../../components/Navbar';
import Button from '../../components/Button';
import Footer from '../../components/Footer';

import './index.css';
function index(props) {
  return (
    <div id='login'>
      
      {/* navbar */}
      <Navbar/>

      {/* header */}
      <section id='header'>
        <img className="image" src={process.env.PUBLIC_URL + '/img/login.png'} alt="" />
      </section>
     <div className="box"></div>
      {/* content */}
      <section id='content'>
        <div className="container">
          <div className="row">
            <div className="col-6 px-5">
              <h1 className='fw-bold' style={{ fontSize:"72px", color:"#1B6A68" }}>Masuk</h1>
              <p className='fw-bold' style={{ fontSize:"32px", color:"#1B6A68" }}>Ayo latih pengetahuanmu bersama Eduton Id</p>
            </div>
          </div>
          <div className="row justify-content-center mt-5">
            <div className="col-6 " >
              <form action="" className='form-group'>
                <div className="">
                  <p className='fw-bold' style={{ fontSize:"26px", color:"#1B6A68" }}>Email</p>
                  <input type="text" className='form-control myInput' placeholder='Masukan Email'/>
                </div>
                <div className="mt-3">
                  <p className='fw-bold' style={{ fontSize:"26px", color:"#1B6A68" }}>Password</p>
                  <input type="text" className='form-control myInput' placeholder='Masukan Password'/>
                </div>
                <div className="mt-3">
                  <div className="row">
                    <div className="col-6">
                      <div className="form-check">
                        <input className="form-check-input" type="checkbox" defaultValue id="flexCheckDefault" />
                        <label className="form-check-label" htmlFor="flexCheckDefault" style={{ fontSize:"15px", color:"#1B6A68" }}>
                          Ingat Bapakmu
                        </label>
                      </div>              
                    </div>
                    <div className="col-6 text-end ">
                        <p href="" className='' style={{ fontSize:"15px", color:"#1B6A68" }}> Lupa Password?</p>             
                    </div>
                  </div>
                </div>
                <div className="row ">
                  <div className="col-6">
                    <button className='btn py-4 fw-bold' style={{ borderRadius:"20px", backgroundColor:"#4DB7B5", padding:"10px 290px", fontSize:"20px", color:"#ffffff" }}>Masuk</button>
                  </div>
                </div>  
                <div className="row text-center mt-4">
                  <span style={{ fontSize:"", color:"#1B6A68" }}>Belum punya akun? <span style={{ color:"1B6A68" }} className='fw-bold'>daftar</span></span>
                </div>
              </form>
            </div>
          </div>
          

          
        </div>

        {/* masih di dalam konten */}
         {/* footer */}
         <section id='footer' style={{ marginTop:"300px" }}>
          <Footer/>
        </section>

      </section>

       
    </div>
  );
}

export default index;