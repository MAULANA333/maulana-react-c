import React from 'react';
import Navbar from '../../components/Navbar';
import Button from '../../components/Button';
import Footer from '../../components/Footer';

import './index.css';
function index(props) {
  return (
    <div id='Certificate'>
        <section id="">
          <div className="container">
            <div className="row">
              <div className="col-md-12">
                 <img style={{ width: "100%" }} className="" src={process.env.PUBLIC_URL + '/img/sertifikat.png'} alt="" />
              </div>
            </div>
          </div>
        </section>
    </div>
  );
}

export default index;