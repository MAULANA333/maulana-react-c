import React from 'react';
import Button from '../../components/Button';
import Navbar from '../../components/Navbar';
import Footer from '../../components/Footer';

import './index.css';

function index(props) {
  return (
    <div>
      <div id="katalogGratis">
        {/* header */}
        <section id="header">
          <div id="navbar">
            <Navbar/>
          </div>
          <div className="container">
            <div className="row justify-content-center">
              <div className="col-md-7">
                <div id="header-tittle" >
                  <h1 className='text-center'>Katalog Tryout</h1>
                  <div className="row justify-content-center">
                    <div className="col-md-12">
                      <p className='text-center' style={{ fontSize:"26px" }}>Pilih paket latihanmu sendiri, sesuai kebutuhan belajarmu</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>            
          </div>
        </section>

        {/* search package */}
        <section id='search'>
        <div className="container mt-5">
          <div className="row">
            <div className="col-md-8">
              <input type="cari paket" className=' form form-control myInput' />
            </div>
            <div className="col-md-2">
              <select class="form-select mySelect" aria-label="Default select example">
                <option selected>2022</option>
                <option value="1">2021</option>
              </select>
            </div>
            <div className="col-md-2">
              <Button
                  link="http://localhost:3000/"
                  text="Temukan"
                  color="#1B6A68"
              />
            </div>
          </div>
        </div>
        </section>

        {/* Jenis */}
        <section id="jenis">
          <div className="container">
            <div className="row mt-5">
              <p className='fw-bold' style={{ fontSize:"26px", color:"#20A5A2" }}>Pilih Jenis Paket Latihanmu</p>
            </div>
            <div className="row mt-3">
              <div className="col-md-4">
                <div className="card p-2 shadow" style={{ borderRadius:"20px", backgroundColor:"#4DB7B5" }}>
                  <div className="row">
                    <div className="col-md-5">
                      <img src={process.env.PUBLIC_URL + '/icon/paket-gratis.png'} style={{ backgroundColor:"#ffffff", borderRadius:"20px", padding:"10px", width:"100%" }} alt="" />
                    </div>
                    <div className="col-md-7">
                      <div className="row">
                        <p className='fw-bold mt-2' style={{ fontSize:"38px", color:"#ffffff" }}>Gratis</p>
                        <p className='' style={{ fontSize:"18px", color:"#ffffff", marginTop:"-8%" }}>Akses paket tryout tanpa bayar</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div className="col-md-4">
                <div className="card p-2 shadow" style={{ borderRadius:"20px", backgroundColor:"#EFBC74" }}>
                  <div className="row">
                    <div className="col-md-5">
                      <img src={process.env.PUBLIC_URL + '/icon/paket-cerdas.png'} style={{ backgroundColor:"#ffffff", borderRadius:"20px", padding:"10px", width:"100%" }} alt="" />
                    </div>
                    <div className="col-md-7">
                      <div className="row">
                        <p className='fw-bold mt-2' style={{ fontSize:"38px", color:"#ffffff" }}>Cerdas</p>
                        <p className='' style={{ fontSize:"18px", color:"#ffffff", marginTop:"-8%" }}>Membuat belajarmu lebih mudah</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div className="col-md-4">
                <div className="card p-2 shadow" style={{ borderRadius:"20px", backgroundColor:"#C36469" }}>
                  <div className="row">
                    <div className="col-md-5">
                      <img src={process.env.PUBLIC_URL + '/icon/paket-super.png'} style={{ backgroundColor:"#ffffff", borderRadius:"20px", padding:"10px", width:"100%" }} alt="" />
                    </div>
                    <div className="col-md-7">
                      <div className="row">
                        <p className='fw-bold mt-2' style={{ fontSize:"38px", color:"#ffffff" }}>Super</p>
                        <p className='' style={{ fontSize:"18px", color:"#ffffff", marginTop:"-8%" }}>Mengatasi segalakesulitanmu</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              
            </div>
          </div>
          
        </section>
        
        {/* package */}
        <section id='package'>
          <div className="container mt-5" style={{ backgroundColor:"#CFE6E7", borderRadius:"20px" }}>
            <div className="row">
              <p className='fw-bold mx-3 mt-2' style={{ fontSize:"38px", borderRadius:"10px", color:"#20A5A2" }}>CERDAS</p>
            </div>
            <div className="row">
              <div className="col-md-3 my-3">
                <div className="card shadow " style={{ borderRadius:"20px" }}>
                  <div className="card-body">
                    <div className="row px-2 py-0">
                      <div className="" style={{ height:"146px", backgroundColor:"#C4C4C4", borderRadius:"20px" }}>
                        
                      </div>
                    </div>
                    <div className="row">
                      <p className='fw-bold' style={{ fontSize:"20px", color:"black" }}>Paket UTBK 1 - Sukses masuk PTN</p>
                    </div>
                    <div className="row ">
                      <p className='text-start' style={{ fontSize:"14px", color:"#929799" }}>Rp. 0,-</p>
                    </div>
                    <div className="border mb-2"></div>
                    <div className="row ">
                      <p className='text-start fw-bold' style={{ fontSize:"13px", color:"#DD8100" }}>27 Jan - 2 Feb 2021</p>
                    </div>
                    <div className="row px-2">
                      <Button
                        link="http://localhost:3000/"
                        text="Pilih Paket"
                        color="#1B6A68"
                      />
                    </div>
                  </div>
                </div>
              </div>
              <div className="col-md-3 my-3">
                <div className="card shadow " style={{ borderRadius:"20px" }}>
                  <div className="card-body">
                    <div className="row px-2 py-0">
                      <div className="" style={{ height:"146px", backgroundColor:"#C4C4C4", borderRadius:"20px" }}>
                        
                      </div>
                    </div>
                    <div className="row">
                      <p className='fw-bold' style={{ fontSize:"20px", color:"black" }}>Paket UTBK 1 - Sukses masuk PTN</p>
                    </div>
                    <div className="row ">
                      <p className='text-start' style={{ fontSize:"14px", color:"#929799" }}>Rp. 0,-</p>
                    </div>
                    <div className="border mb-2"></div>
                    <div className="row ">
                      <p className='text-start fw-bold' style={{ fontSize:"13px", color:"#DD8100" }}>27 Jan - 2 Feb 2021</p>
                    </div>
                    <div className="row px-2">
                      <Button
                        link="http://localhost:3000/"
                        text="Pilih Paket"
                        color="#1B6A68"
                      />
                    </div>
                  </div>
                </div>
              </div>
              <div className="col-md-3 my-3">
                <div className="card shadow " style={{ borderRadius:"20px" }}>
                  <div className="card-body">
                    <div className="row px-2 py-0">
                      <div className="" style={{ height:"146px", backgroundColor:"#C4C4C4", borderRadius:"20px" }}>
                        
                      </div>
                    </div>
                    <div className="row">
                      <p className='fw-bold' style={{ fontSize:"20px", color:"black" }}>Paket UTBK 1 - Sukses masuk PTN</p>
                    </div>
                    <div className="row ">
                      <p className='text-start' style={{ fontSize:"14px", color:"#929799" }}>Rp. 0,-</p>
                    </div>
                    <div className="border mb-2"></div>
                    <div className="row ">
                      <p className='text-start fw-bold' style={{ fontSize:"13px", color:"#DD8100" }}>27 Jan - 2 Feb 2021</p>
                    </div>
                    <div className="row px-2">
                      <Button
                        link="http://localhost:3000/"
                        text="Pilih Paket"
                        color="#1B6A68"
                      />
                    </div>
                  </div>
                </div>
              </div>
              <div className="col-md-3 my-3">
                <div className="card shadow " style={{ borderRadius:"20px" }}>
                  <div className="card-body">
                    <div className="row px-2 py-0">
                      <div className="" style={{ height:"146px", backgroundColor:"#C4C4C4", borderRadius:"20px" }}>
                        
                      </div>
                    </div>
                    <div className="row">
                      <p className='fw-bold' style={{ fontSize:"20px", color:"black" }}>Paket UTBK 1 - Sukses masuk PTN</p>
                    </div>
                    <div className="row ">
                      <p className='text-start' style={{ fontSize:"14px", color:"#929799" }}>Rp. 0,-</p>
                    </div>
                    <div className="border mb-2"></div>
                    <div className="row ">
                      <p className='text-start fw-bold' style={{ fontSize:"13px", color:"#DD8100" }}>27 Jan - 2 Feb 2021</p>
                    </div>
                    <div className="row px-2">
                      <Button
                        link="http://localhost:3000/"
                        text="Pilih Paket"
                        color="#1B6A68"
                      />
                    </div>
                  </div>
                </div>
              </div>
              <div className="col-md-3 my-3">
                <div className="card shadow " style={{ borderRadius:"20px" }}>
                  <div className="card-body">
                    <div className="row px-2 py-0">
                      <div className="" style={{ height:"146px", backgroundColor:"#C4C4C4", borderRadius:"20px" }}>
                        
                      </div>
                    </div>
                    <div className="row">
                      <p className='fw-bold' style={{ fontSize:"20px", color:"black" }}>Paket UTBK 1 - Sukses masuk PTN</p>
                    </div>
                    <div className="row ">
                      <p className='text-start' style={{ fontSize:"14px", color:"#929799" }}>Rp. 0,-</p>
                    </div>
                    <div className="border mb-2"></div>
                    <div className="row ">
                      <p className='text-start fw-bold' style={{ fontSize:"13px", color:"#DD8100" }}>27 Jan - 2 Feb 2021</p>
                    </div>
                    <div className="row px-2">
                      <Button
                        link="http://localhost:3000/"
                        text="Pilih Paket"
                        color="#1B6A68"
                      />
                    </div>
                  </div>
                </div>
              </div>
              <div className="col-md-3 my-3">
                <div className="card shadow " style={{ borderRadius:"20px" }}>
                  <div className="card-body">
                    <div className="row px-2 py-0">
                      <div className="" style={{ height:"146px", backgroundColor:"#C4C4C4", borderRadius:"20px" }}>
                        
                      </div>
                    </div>
                    <div className="row">
                      <p className='fw-bold' style={{ fontSize:"20px", color:"black" }}>Paket UTBK 1 - Sukses masuk PTN</p>
                    </div>
                    <div className="row ">
                      <p className='text-start' style={{ fontSize:"14px", color:"#929799" }}>Rp. 0,-</p>
                    </div>
                    <div className="border mb-2"></div>
                    <div className="row ">
                      <p className='text-start fw-bold' style={{ fontSize:"13px", color:"#DD8100" }}>27 Jan - 2 Feb 2021</p>
                    </div>
                    <div className="row px-2">
                      <Button
                        link="http://localhost:3000/"
                        text="Pilih Paket"
                        color="#1B6A68"
                      />
                    </div>
                  </div>
                </div>
              </div>
              <div className="col-md-3 my-3">
                <div className="card shadow " style={{ borderRadius:"20px" }}>
                  <div className="card-body">
                    <div className="row px-2 py-0">
                      <div className="" style={{ height:"146px", backgroundColor:"#C4C4C4", borderRadius:"20px" }}>
                        
                      </div>
                    </div>
                    <div className="row">
                      <p className='fw-bold' style={{ fontSize:"20px", color:"black" }}>Paket UTBK 1 - Sukses masuk PTN</p>
                    </div>
                    <div className="row ">
                      <p className='text-start' style={{ fontSize:"14px", color:"#929799" }}>Rp. 0,-</p>
                    </div>
                    <div className="border mb-2"></div>
                    <div className="row ">
                      <p className='text-start fw-bold' style={{ fontSize:"13px", color:"#DD8100" }}>27 Jan - 2 Feb 2021</p>
                    </div>
                    <div className="row px-2">
                      <Button
                        link="http://localhost:3000/"
                        text="Pilih Paket"
                        color="#1B6A68"
                      />
                    </div>
                  </div>
                </div>
              </div>
              <div className="col-md-3 my-3">
                <div className="card shadow " style={{ borderRadius:"20px" }}>
                  <div className="card-body">
                    <div className="row px-2 py-0">
                      <div className="" style={{ height:"146px", backgroundColor:"#C4C4C4", borderRadius:"20px" }}>
                        
                      </div>
                    </div>
                    <div className="row">
                      <p className='fw-bold' style={{ fontSize:"20px", color:"black" }}>Paket UTBK 1 - Sukses masuk PTN</p>
                    </div>
                    <div className="row ">
                      <p className='text-start' style={{ fontSize:"14px", color:"#929799" }}>Rp. 0,-</p>
                    </div>
                    <div className="border mb-2"></div>
                    <div className="row ">
                      <p className='text-start fw-bold' style={{ fontSize:"13px", color:"#DD8100" }}>27 Jan - 2 Feb 2021</p>
                    </div>
                    <div className="row px-2">
                      <Button
                        link="http://localhost:3000/"
                        text="Pilih Paket"
                        color="#1B6A68"
                      />
                    </div>
                  </div>
                </div>
              </div>
              <div className="col-md-3 my-3">
                <div className="card shadow " style={{ borderRadius:"20px" }}>
                  <div className="card-body">
                    <div className="row px-2 py-0">
                      <div className="" style={{ height:"146px", backgroundColor:"#C4C4C4", borderRadius:"20px" }}>
                        
                      </div>
                    </div>
                    <div className="row">
                      <p className='fw-bold' style={{ fontSize:"20px", color:"black" }}>Paket UTBK 1 - Sukses masuk PTN</p>
                    </div>
                    <div className="row ">
                      <p className='text-start' style={{ fontSize:"14px", color:"#929799" }}>Rp. 0,-</p>
                    </div>
                    <div className="border mb-2"></div>
                    <div className="row ">
                      <p className='text-start fw-bold' style={{ fontSize:"13px", color:"#DD8100" }}>27 Jan - 2 Feb 2021</p>
                    </div>
                    <div className="row px-2">
                      <Button
                        link="http://localhost:3000/"
                        text="Pilih Paket"
                        color="#1B6A68"
                      />
                    </div>
                  </div>
                </div>
              </div>
              <div className="col-md-3 my-3">
                <div className="card shadow " style={{ borderRadius:"20px" }}>
                  <div className="card-body">
                    <div className="row px-2 py-0">
                      <div className="" style={{ height:"146px", backgroundColor:"#C4C4C4", borderRadius:"20px" }}>
                        
                      </div>
                    </div>
                    <div className="row">
                      <p className='fw-bold' style={{ fontSize:"20px", color:"black" }}>Paket UTBK 1 - Sukses masuk PTN</p>
                    </div>
                    <div className="row ">
                      <p className='text-start' style={{ fontSize:"14px", color:"#929799" }}>Rp. 0,-</p>
                    </div>
                    <div className="border mb-2"></div>
                    <div className="row ">
                      <p className='text-start fw-bold' style={{ fontSize:"13px", color:"#DD8100" }}>27 Jan - 2 Feb 2021</p>
                    </div>
                    <div className="row px-2">
                      <Button
                        link="http://localhost:3000/"
                        text="Pilih Paket"
                        color="#1B6A68"
                      />
                    </div>
                  </div>
                </div>
              </div>
              <div className="col-md-3 my-3">
                <div className="card shadow " style={{ borderRadius:"20px" }}>
                  <div className="card-body">
                    <div className="row px-2 py-0">
                      <div className="" style={{ height:"146px", backgroundColor:"#C4C4C4", borderRadius:"20px" }}>
                        
                      </div>
                    </div>
                    <div className="row">
                      <p className='fw-bold' style={{ fontSize:"20px", color:"black" }}>Paket UTBK 1 - Sukses masuk PTN</p>
                    </div>
                    <div className="row ">
                      <p className='text-start' style={{ fontSize:"14px", color:"#929799" }}>Rp. 0,-</p>
                    </div>
                    <div className="border mb-2"></div>
                    <div className="row ">
                      <p className='text-start fw-bold' style={{ fontSize:"13px", color:"#DD8100" }}>27 Jan - 2 Feb 2021</p>
                    </div>
                    <div className="row px-2">
                      <Button
                        link="http://localhost:3000/"
                        text="Pilih Paket"
                        color="#1B6A68"
                      />
                    </div>
                  </div>
                </div>
              </div>
              <div className="col-md-3 my-3">
                <div className="card shadow " style={{ borderRadius:"20px" }}>
                  <div className="card-body">
                    <div className="row px-2 py-0">
                      <div className="" style={{ height:"146px", backgroundColor:"#C4C4C4", borderRadius:"20px" }}>
                        
                      </div>
                    </div>
                    <div className="row">
                      <p className='fw-bold' style={{ fontSize:"20px", color:"black" }}>Paket UTBK 1 - Sukses masuk PTN</p>
                    </div>
                    <div className="row ">
                      <p className='text-start' style={{ fontSize:"14px", color:"#929799" }}>Rp. 0,-</p>
                    </div>
                    <div className="border mb-2"></div>
                    <div className="row ">
                      <p className='text-start fw-bold' style={{ fontSize:"13px", color:"#DD8100" }}>27 Jan - 2 Feb 2021</p>
                    </div>
                    <div className="row px-2">
                      <Button
                        link="http://localhost:3000/"
                        text="Pilih Paket"
                        color="#1B6A68"
                      />
                    </div>
                  </div>
                </div>
              </div>
              <div className="col-md-3 my-3">
                <div className="card shadow " style={{ borderRadius:"20px" }}>
                  <div className="card-body">
                    <div className="row px-2 py-0">
                      <div className="" style={{ height:"146px", backgroundColor:"#C4C4C4", borderRadius:"20px" }}>
                        
                      </div>
                    </div>
                    <div className="row">
                      <p className='fw-bold' style={{ fontSize:"20px", color:"black" }}>Paket UTBK 1 - Sukses masuk PTN</p>
                    </div>
                    <div className="row ">
                      <p className='text-start' style={{ fontSize:"14px", color:"#929799" }}>Rp. 0,-</p>
                    </div>
                    <div className="border mb-2"></div>
                    <div className="row ">
                      <p className='text-start fw-bold' style={{ fontSize:"13px", color:"#DD8100" }}>27 Jan - 2 Feb 2021</p>
                    </div>
                    <div className="row px-2">
                      <Button
                        link="http://localhost:3000/"
                        text="Pilih Paket"
                        color="#1B6A68"
                      />
                    </div>
                  </div>
                </div>
              </div>
              <div className="col-md-3 my-3">
                <div className="card shadow " style={{ borderRadius:"20px" }}>
                  <div className="card-body">
                    <div className="row px-2 py-0">
                      <div className="" style={{ height:"146px", backgroundColor:"#C4C4C4", borderRadius:"20px" }}>
                        
                      </div>
                    </div>
                    <div className="row">
                      <p className='fw-bold' style={{ fontSize:"20px", color:"black" }}>Paket UTBK 1 - Sukses masuk PTN</p>
                    </div>
                    <div className="row ">
                      <p className='text-start' style={{ fontSize:"14px", color:"#929799" }}>Rp. 0,-</p>
                    </div>
                    <div className="border mb-2"></div>
                    <div className="row ">
                      <p className='text-start fw-bold' style={{ fontSize:"13px", color:"#DD8100" }}>27 Jan - 2 Feb 2021</p>
                    </div>
                    <div className="row px-2">
                      <Button
                        link="http://localhost:3000/"
                        text="Pilih Paket"
                        color="#1B6A68"
                      />
                    </div>
                  </div>
                </div>
              </div>
              <div className="col-md-3 my-3">
                <div className="card shadow " style={{ borderRadius:"20px" }}>
                  <div className="card-body">
                    <div className="row px-2 py-0">
                      <div className="" style={{ height:"146px", backgroundColor:"#C4C4C4", borderRadius:"20px" }}>
                        
                      </div>
                    </div>
                    <div className="row">
                      <p className='fw-bold' style={{ fontSize:"20px", color:"black" }}>Paket UTBK 1 - Sukses masuk PTN</p>
                    </div>
                    <div className="row ">
                      <p className='text-start' style={{ fontSize:"14px", color:"#929799" }}>Rp. 0,-</p>
                    </div>
                    <div className="border mb-2"></div>
                    <div className="row ">
                      <p className='text-start fw-bold' style={{ fontSize:"13px", color:"#DD8100" }}>27 Jan - 2 Feb 2021</p>
                    </div>
                    <div className="row px-2">
                      <Button
                        link="http://localhost:3000/"
                        text="Pilih Paket"
                        color="#1B6A68"
                      />
                    </div>
                  </div>
                </div>
              </div>
              <div className="col-md-3 my-3">
                <div className="card shadow " style={{ borderRadius:"20px" }}>
                  <div className="card-body">
                    <div className="row px-2 py-0">
                      <div className="" style={{ height:"146px", backgroundColor:"#C4C4C4", borderRadius:"20px" }}>
                        
                      </div>
                    </div>
                    <div className="row">
                      <p className='fw-bold' style={{ fontSize:"20px", color:"black" }}>Paket UTBK 1 - Sukses masuk PTN</p>
                    </div>
                    <div className="row ">
                      <p className='text-start' style={{ fontSize:"14px", color:"#929799" }}>Rp. 0,-</p>
                    </div>
                    <div className="border mb-2"></div>
                    <div className="row ">
                      <p className='text-start fw-bold' style={{ fontSize:"13px", color:"#DD8100" }}>27 Jan - 2 Feb 2021</p>
                    </div>
                    <div className="row px-2">
                      <Button
                        link="http://localhost:3000/"
                        text="Pilih Paket"
                        color="#1B6A68"
                      />
                    </div>
                  </div>
                </div>
              </div>
              <div className="col-md-3 my-3">
                <div className="card shadow " style={{ borderRadius:"20px" }}>
                  <div className="card-body">
                    <div className="row px-2 py-0">
                      <div className="" style={{ height:"146px", backgroundColor:"#C4C4C4", borderRadius:"20px" }}>
                        
                      </div>
                    </div>
                    <div className="row">
                      <p className='fw-bold' style={{ fontSize:"20px", color:"black" }}>Paket UTBK 1 - Sukses masuk PTN</p>
                    </div>
                    <div className="row ">
                      <p className='text-start' style={{ fontSize:"14px", color:"#929799" }}>Rp. 0,-</p>
                    </div>
                    <div className="border mb-2"></div>
                    <div className="row ">
                      <p className='text-start fw-bold' style={{ fontSize:"13px", color:"#DD8100" }}>27 Jan - 2 Feb 2021</p>
                    </div>
                    <div className="row px-2">
                      <Button
                        link="http://localhost:3000/"
                        text="Pilih Paket"
                        color="#1B6A68"
                      />
                    </div>
                  </div>
                </div>
              </div>
              <div className="col-md-3 my-3">
                <div className="card shadow " style={{ borderRadius:"20px" }}>
                  <div className="card-body">
                    <div className="row px-2 py-0">
                      <div className="" style={{ height:"146px", backgroundColor:"#C4C4C4", borderRadius:"20px" }}>
                        
                      </div>
                    </div>
                    <div className="row">
                      <p className='fw-bold' style={{ fontSize:"20px", color:"black" }}>Paket UTBK 1 - Sukses masuk PTN</p>
                    </div>
                    <div className="row ">
                      <p className='text-start' style={{ fontSize:"14px", color:"#929799" }}>Rp. 0,-</p>
                    </div>
                    <div className="border mb-2"></div>
                    <div className="row ">
                      <p className='text-start fw-bold' style={{ fontSize:"13px", color:"#DD8100" }}>27 Jan - 2 Feb 2021</p>
                    </div>
                    <div className="row px-2">
                      <Button
                        link="http://localhost:3000/"
                        text="Pilih Paket"
                        color="#1B6A68"
                      />
                    </div>
                  </div>
                </div>
              </div>
              <div className="col-md-3 my-3">
                <div className="card shadow " style={{ borderRadius:"20px" }}>
                  <div className="card-body">
                    <div className="row px-2 py-0">
                      <div className="" style={{ height:"146px", backgroundColor:"#C4C4C4", borderRadius:"20px" }}>
                        
                      </div>
                    </div>
                    <div className="row">
                      <p className='fw-bold' style={{ fontSize:"20px", color:"black" }}>Paket UTBK 1 - Sukses masuk PTN</p>
                    </div>
                    <div className="row ">
                      <p className='text-start' style={{ fontSize:"14px", color:"#929799" }}>Rp. 0,-</p>
                    </div>
                    <div className="border mb-2"></div>
                    <div className="row ">
                      <p className='text-start fw-bold' style={{ fontSize:"13px", color:"#DD8100" }}>27 Jan - 2 Feb 2021</p>
                    </div>
                    <div className="row px-2">
                      <Button
                        link="http://localhost:3000/"
                        text="Pilih Paket"
                        color="#1B6A68"
                      />
                    </div>
                  </div>
                </div>
              </div>
              <div className="col-md-3 my-3">
                <div className="card shadow " style={{ borderRadius:"20px" }}>
                  <div className="card-body">
                    <div className="row px-2 py-0">
                      <div className="" style={{ height:"146px", backgroundColor:"#C4C4C4", borderRadius:"20px" }}>
                        
                      </div>
                    </div>
                    <div className="row">
                      <p className='fw-bold' style={{ fontSize:"20px", color:"black" }}>Paket UTBK 1 - Sukses masuk PTN</p>
                    </div>
                    <div className="row ">
                      <p className='text-start' style={{ fontSize:"14px", color:"#929799" }}>Rp. 0,-</p>
                    </div>
                    <div className="border mb-2"></div>
                    <div className="row ">
                      <p className='text-start fw-bold' style={{ fontSize:"13px", color:"#DD8100" }}>27 Jan - 2 Feb 2021</p>
                    </div>
                    <div className="row px-2">
                      <Button
                        link="http://localhost:3000/"
                        text="Pilih Paket"
                        color="#1B6A68"
                      />
                    </div>
                  </div>
                </div>
              </div>
             
            </div>
          </div>
        </section>

        {/* footer */}
        <Footer/>
      </div>
    </div>
  );
}

export default index;