import React from 'react';
import './index.css';

function index(props) {
  return (
    <div id='exercise' className='py-5' style={{ backgroundColor:"#EAEEF0" }}>
      <div className="container" >
        <div className="row">
          <div className="col-7 p-3" style={{ backgroundColor:"#CFE6E7",borderRadius:"20px" }}>
            <div className="row">
              <div className="col-md-9">
                <div className="card p-3" style={{ borderRadius:"20px"  }}>
                  <p className='fw-bold' style={{ fontSize:"38px", color:"#1B6A68" }}>Bagian 1</p>
                  <p className='fw-bold' style={{ fontSize:"26px", color:"#1B6A68" }}>Penalaran Umum</p>
                </div>
              </div>
              <div className="col-md-3">
              <div className="card p-3"style={{ borderRadius:"20px" }}>
                <p className='fw-bold py-4 text-center' style={{ fontSize:"48px", color:"#1B6A68", backgroundColor:"#EAEEF0",borderRadius:"50%" }}>5</p>
              </div>
              </div>
            </div>
            <div className="row">
              <div className="col-12">
                <div className="card p-3" style={{ borderRadius:"20px" }}>
                  <p className='' style={{ fontSize:"18px", color:"#1B6A68" }}>Sejak awal Maret 2020, pandemi Covid-19 menyebabkan perubahan signifikan terhadap industri film secara global. Di berbagai belahan dunia, industri film mengalami chaos, dan semua stakeholder industri perfilman terpaksa memutar otak untuk dapat bertahan. Di Indonesia, sebagian film terbaru membatalkan penayangannya karena terdampak Pembatasan Sosial Berskala Besar (PSBB), termasuk ketatnya peraturan protokol kesehatan. Realita dari berbagai film terbaru di masa pandemi adalah distribusi yang macet. Dalam hal ini, semua film tersebut sangat mengandalkan saluran bioskop. Pasar konsumen yang dijangkau semakin luas atau potensi pendapatan industri perfilman semakin tinggi apabila semakin banyak layar bioskop yang ada untuk penayangan berbagai film.</p>
                  <p className='mt-3' style={{ fontSize:"18px", color:"#1B6A68" }}>Polemik buka-tutup-buka bioskop menjadi ironi tersendiri di tengah meningkatnya pertumbuhan bioskop lima tahun terakhir sebelum pandemi. Semenjak Oktober 2020, beberapa bioskop di Indonesia sudah kembali buka secara bertahap, namun kondisinya masih jauh dari normal. Setiap kebijakan pembatasan sosial yang ditetapkan dari pemerintah akan menurunkan daya beli masyarakat terhadap bisnis perfilman. Turunnya daya beli masyarakat tersebut menyebabkan penurunan jumlah penonton di bioskop dan kualitas film yang tidak optimal. </p>
                  <p className='mt-3' style={{ fontSize:"18px", color:"#1B6A68" }}>Namun di sisi lain, bencana pandemi justru memantik peningkatan </p>
                </div>
              </div>
            </div>
            <div className="row">
              <div className="col-12">
                <div className="card p-3 mt-3" style={{ borderRadius:"20px", boxShadow:"0px 4px 4px rgba(0, 0, 0, 0.25)" }}>
                  <div className="row">
                    <div className="col-1">
                      <div className="px-2 mt-2" style={{ width:"120%", backgroundColor:"#EAEEF0",borderRadius:"50%"  }}>
                        <p className='fw-bold p-2 text-center' style={{ fontSize:"26px", color:"#1B6A68", }}>A</p>
                      </div>
                    </div>
                    <div className="col-9">
                      <p className='pt-2 ms-3' style={{ fontSize:"18px", color:"#1B6A68", }}>Sebagian film yang tetap ingin melakukan penayangan sangat mengandalkan saluran bioskop.</p>
                    </div>
                  </div>
                </div>
                <div className="card p-3 mt-3" style={{ borderRadius:"20px", boxShadow:"0px 4px 4px rgba(0, 0, 0, 0.25)" }}>
                  <div className="row">
                    <div className="col-1">
                      <div className="px-2 mt-2" style={{ width:"120%", backgroundColor:"#EAEEF0",borderRadius:"50%"  }}>
                        <p className='fw-bold p-2 text-center' style={{ fontSize:"26px", color:"#1B6A68", }}>B</p>
                      </div>
                    </div>
                    <div className="col-9">
                      <p className='pt-2 ms-3' style={{ fontSize:"18px", color:"#1B6A68", }}>Semua film terbaru yang sangat mengandalkan saluran bioskop resmi membatalkan penayangannya.</p>
                    </div>
                  </div>
                </div>
                <div className="card p-3 mt-3" style={{ borderRadius:"20px", boxShadow:"0px 4px 4px rgba(0, 0, 0, 0.25)", backgroundColor:"#A6DBDA" }}>
                  <div className="row">
                    <div className="col-1">
                      <div className="px-2 mt-2" style={{ width:"120%", backgroundColor:"#20A5A2",borderRadius:"50%"  }}>
                        <p className='fw-bold p-2 text-center' style={{ fontSize:"26px", color:"#ffffff", }}>C</p>
                      </div>
                    </div>
                    <div className="col-9">
                      <p className='pt-2 ms-3' style={{ fontSize:"18px", color:"#1B6A68", }}>Sebagian film terbaru yang membatalkan penayangan sangat mengandalkan saluran bioskop.</p>
                    </div>
                  </div>
                </div>
                <div className="card p-3 mt-3" style={{ borderRadius:"20px", boxShadow:"0px 4px 4px rgba(0, 0, 0, 0.25)" }}>
                  <div className="row">
                    <div className="col-1">
                      <div className="px-2 mt-2" style={{ width:"120%", backgroundColor:"#EAEEF0",borderRadius:"50%"  }}>
                        <p className='fw-bold p-2 text-center' style={{ fontSize:"26px", color:"#1B6A68", }}>D</p>
                      </div>
                    </div>
                    <div className="col-9">
                      <p className='pt-2 ms-3' style={{ fontSize:"18px", color:"#1B6A68", }}>Tidak ada film terbaru yang akan melakukan penayangan meskipun sangat mengandalkan saluran bioskop.</p>
                    </div>
                  </div>
                </div>
                <div className="card p-3 mt-3" style={{ borderRadius:"20px", boxShadow:"0px 4px 4px rgba(0, 0, 0, 0.25)" }}>
                  <div className="row">
                    <div className="col-1">
                      <div className="px-2 mt-2" style={{ width:"120%", backgroundColor:"#EAEEF0",borderRadius:"50%"  }}>
                        <p className='fw-bold p-2 text-center' style={{ fontSize:"26px", color:"#1B6A68", }}>E</p>
                      </div>
                    </div>
                    <div className="col-9">
                      <p className='pt-2 ms-3' style={{ fontSize:"18px", color:"#1B6A68", }}>Sebagian film terbaru yang akan membatalkan penayangan, tidak mengandalkan saluran bioskop.</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className="row mt-3">
              <div className="col-4">
                <button className='btn rounded-pill bg-light py-2 px-5' style={{ fontSize:"26px", color:"#20A5A2" }}>Kembali</button>
              </div>
              <div className="col-4 text-end">
                  <button className='btn rounded-pill py-2 px-5' style={{ fontSize:"26px", color:"#ffffff", backgroundColor:"#F3CD97" }}>Ragu-ragu</button>
              </div>
              <div className="col-2">
                  <button className='btn rounded-pill py-2 px-5 ' style={{ fontSize:"26px", color:"#ffffff", backgroundColor:"#4DB7B5" }}>Selanjutnya</button>
              </div>
            </div>
          </div>
          <div className="col-4 ms-3">
            <div className="row p-4" style={{ backgroundColor:"#CFE6E7", borderRadius:"20px" }}>
              <div className="card p-2" style={{ borderRadius:"8px" }}>
                <p className='fw-bold text-center pt-2' style={{ fontSize:"38px", color:"#1B6A68" }}>00 : 52 : 56</p>
              </div>
            </div>
            <div className="row p-2 mt-3" style={{ backgroundColor:"#CFE6E7", borderRadius:"20px" }}>
              <p className='fw-bold mt-3' style={{ fontSize:"38px", color:"#1B6A68" }}>Bagian</p>
              <div className="row">
                <div className="col-2">
                  <div className=" mt-2" style={{ backgroundColor:"#EAEEF0",borderRadius:"20px"  }}>
                    <p className='fw-bold py-2 text-center' style={{ fontSize:"38px", color:"#1B6A68", }}>1</p>
                  </div>
                </div>
                <div className="col-3">
                  <div className=" mt-2" style={{marginLeft:"-20%", marginRight:"20%", backgroundColor:"#EAEEF0",borderRadius:"20px"  }}>
                    <p className='fw-bold p-2 text-center' style={{ fontSize:"38px", color:"#1B6A68", }}>2</p>
                  </div>
                </div>
                <div className="col-3">
                  <div className=" mt-2" style={{marginLeft:"-40%", marginRight:"40%", backgroundColor:"#EAEEF0",borderRadius:"20px"  }}>
                    <p className='fw-bold p-2 text-center' style={{ fontSize:"38px", color:"#1B6A68", }}>3</p>
                  </div>
                </div>
                <div className="col-3">
                  <div className=" mt-2" style={{ marginLeft:"-60%", marginRight:"60%",  backgroundColor:"#EAEEF0",borderRadius:"20px"  }}>
                    <p className='fw-bold p-2 text-center' style={{fontSize:"38px", color:"#1B6A68", }}>4</p>
                  </div>
                </div>
              </div>
              <div className="row mt-2 px-5">
                <div className="px-4 text-center" style={{ backgroundColor:"#4DB7B5", borderRadius:"20px" }}>
                  <p className='fw-bold text-center pt-2' style={{ fontSize:"26px", color:"#ffffff" }}>Bagian Selanjutnya</p>
                </div>
              </div>
              <div className="row mt-3 px-5">
              </div>
            </div>
            
          </div>
        </div>
      </div>
    </div>
  );
}

export default index;