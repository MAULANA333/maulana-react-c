import React from 'react';
import Button from '../../components/Button';
import Navbar from '../../components/Navbar';
import Footer from '../../components/Footer';
// import Tabs from '../../components/Tabs/Tabs';
import Tabs from 'react-bootstrap/Tabs';
import 'bootstrap/dist/css/bootstrap.css';
import Tab from 'react-bootstrap/Tab';
import './index.css';

function index(props) {
  return (
    <div>
      <div id="payment2">
         {/* header */}
         <section id="header">
            <div id="navbar">
              <Navbar/>
            </div>
            <div className="container">
              <div className="row justify-content-center">
                <div className="col-md-7">
                  <div id="header-tittle" >
                    <h1 className='text-center'>Bayar Paket</h1>
                    <div className="row justify-content-center">
                      <div className="col-md-12">
                        <p className='text-center' style={{ fontSize:"26px" }}>Bergabung menjadi Edusob dan latih pengetahuanmu</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>            
            </div>
          </section>
          
          {/* content */}
          <section id='content'>
            <div className="container">
              <div className="row">
                <div className="col-5 mt-3">
                  <div className="card payment-card p-5" style={{ borderRadius:"20px" }}>
                    <div className="row">
                      <p className='fw-bold' style={{ fontSize:"32px", color:"#1B6A68" }} >Pilih Metode Pembayaran</p>
                    </div>
                    <div style={{ display: 'block' }}>
                      <Tabs defaultActiveKey="first">
                        <Tab eventKey="first" title="E-money" >
                          <div className="row mt-5 p-2 " style={{ border: "2px solid #79C9C7",borderRadius:"20px", boxSizing: "border-box" }}>
                            <p style={{ fontSize:"26px", color:"#1B6A68" }} >Dana</p>
                          </div>
                          <div className="row mt-3 p-2 " style={{ border: "2px solid #79C9C7",borderRadius:"20px", boxSizing: "border-box" }}>
                            <p style={{ fontSize:"26px", color:"#1B6A68" }} >ShopeePay</p>
                          </div>
                          <div className="row mt-3 p-2 " style={{ border: "2px solid #79C9C7",borderRadius:"20px", boxSizing: "border-box" }}>
                            <p style={{ fontSize:"26px", color:"#1B6A68" }} >Gopay</p>
                          </div>
                          <div className="row mt-3 p-2 " style={{ border: "2px solid #79C9C7",borderRadius:"20px", boxSizing: "border-box" }}>
                            <p style={{ fontSize:"26px", color:"#1B6A68" }} >LinkAja</p>
                          </div>
                          <div className="row mt-3 p-2 " style={{ border: "2px solid #79C9C7",borderRadius:"20px", boxSizing: "border-box" }}>
                            <p style={{ fontSize:"26px", color:"#1B6A68" }} >Ovo</p>
                          </div>
                        </Tab>
                        <Tab eventKey="second" title="Bank">
                          <div className="row mt-5 p-2 " style={{ border: "2px solid #79C9C7",borderRadius:"20px", boxSizing: "border-box" }}>
                            <p style={{ fontSize:"26px", color:"#1B6A68" }} >BCA</p>
                          </div>
                        </Tab>
                      </Tabs>
                    </div>
                  </div>
                  
                  <div className="card payment-card2 p-5 mt-4" style={{ borderRadius:"20px" }}>
                    <div className="row ">
                      <div className="card">
                        
                      </div>
                      <p className="fw-bold" style={{ fontSize:"32px", color:"#1B6A68" }} >Informasi Penting</p>
                      <p className=" mt-3" style={{ fontSize:"20px", color:"#1B6A68" }} >Proses konfirmasi pembayaran paket melalui WhatsApp dan akan dikonfirmasi sesuai jam kerja. Mohon menunggu dengan sabar dan terima kasih.</p>
                      <p className="fw-bold" style={{ fontSize:"20px", color:"#1B6A68" }} >Masih bingung?</p>
                      <p className="" style={{ fontSize:"20px", color:"#1B6A68" }} >Admin</p>
                      <div className="col-6">
                        <p className="" style={{ fontSize:"20px", color:"#1B6A68" }} >No. WhatsApp</p>
                      </div>
                      <div className="col-6">
                        <p className="text-end" style={{ fontSize:"20px", color:"#1B6A68" }} >009237483272</p>
                      </div>
                        <p className="fw-bold mt-5 text-center" style={{ fontSize:"20px", color:"#1B6A68" }} >Hubungi Admin</p>
                    </div>
                  </div>
                </div>
                <div className="col-7">
                  

                  <div className="row">
                  
                  </div>
                </div>
              </div>
            </div>
          </section>
          {/* footer */}
          <Footer/>
      </div>
    </div>
  );
}

export default index;

{/* <Tabs>
  <div label="Gator">
    See ya later, <em>Alligator</em>!
  </div>
  <div label="Croc">
    After 'while, <em>Crocodile</em>!
  </div>
  <div label="Sarcosuchus">
    Nothing to see here, this tab is <em>extinct</em>!
  </div>
</Tabs> */}