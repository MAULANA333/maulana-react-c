import React from 'react';
import Navbar from '../../components/Navbar';
import Button from '../../components/Button';
import Footer from '../../components/Footer';

import './index.css';
function index(props) {
  return (
    <div id='blogView'>
        {/* header */}
        <section id="">
          <div id="navbar">
            <Navbar/>
          </div>
        </section>

        {/* tittle */}
        <section id="tittle">
          <div className="container mt-5 p-5 shadow-sm" style={{ borderRadius:"20px", backgroundColor:"#CFE6E7" }}>
            <div className="row justify-content-center">
              <div className="gambar" >

              </div>
            </div>
            <div className="row">
              <div className="col-11">
                <p className='fw-bold my-2' style={{ fontSize:"42px", color:"#1B6A68" }}>UTBK Fest - Pejuang Gap Year dan Berkarier di Industri Kreatif</p>
                <p className='fw-bold mt-3' style={{ fontSize:"24px", color:"#1B6A68" }}>Handoyo Dwi Prasetyo</p>
                <p className='' style={{ fontSize:"20px", color:"#DD8100" }}>Rabu, 13 Februari 2022</p>
              </div>
            </div>
          </div>
        </section>

        {/* body */}
        <section id="blogBody">
          <div className="container mt-5 p-5 shadow-sm" style={{ borderRadius:"20px", backgroundColor:"#CFE6E7" }}>
            <p className=' fw-bold my-2' style={{ fontSize:"20px", color:"#1B6A68" }}>Gagal masuk PTN tahun ini, mending gap year atau kuliah seadanya? Yuk, simak kisah sukses pejuang gap year. Punya motivasi gap year yang terarah, menunda kuliah setahun bisa terasa banget faedahnya.</p>
            <p className='mt-4 my-2' style={{ fontSize:"20px", color:"#1B6A68" }}>Edusob, elo familiar nggak sama ungkapan “ada banyak jalan menuju Roma”? Kalau menurut ungkapan ini, ketika elo punya suatu tujuan, jalan menuju ke sana nggak cuma satu! Ada belokan-belokan yang bisa elo ambil dan tetap bisa sampai tujuan kayak orang-orang yang mengambil “jalan utama”. Sama, nih, halnya dengan perjuangan kuliah di PTN (Perguruan Tinggi Negeri) yang jadi incaran elo.</p>
            <p className='mt-4 my-2' style={{ fontSize:"20px", color:"#1B6A68" }}>Misalnya, tahun ini elo mencoba lewat berbagai jalur kayak SNMPTN (undangan), UTBK (ujian tulis), ujian mandiri, tapi masih gagal juga? Duh, harus gimana lagi ya…</p>
            <p className='mt-4 my-2' style={{ fontSize:"20px", color:"#1B6A68" }}>Eitss, elo masih bisa punya pilihan gap year, lho.</p>
            <p className='mt-4 my-2' style={{ fontSize:"20px", color:"#1B6A68" }}>Di hari terakhir UTBK Fest Alumni & Career Day (Jumat, 04/02/2022) bertajuk Gap Year Bukan Juga Pilihan, hadir Esa Trisaputra, Zeroes Zenius sekaligus pejuang gap year pada masanya. Gue mendapatkan banyak insight kalau gap year nggak seburuk yang dikira selama ini, lho! Asalkan punya motivasi gap year yang terarah, menunda kuliah setahun bisa terasa banget faedahnya.</p>
            <p className='mt-4 mb-5 my-2' style={{ fontSize:"20px", color:"#1B6A68" }}>Selain itu, ada juga cerita seru dari Bimo Kusumo Yudo di sesi Berkarier di Bidang Industri Kreatif. Bimo membagikan cerita-cerita seru seputar profesinya sebagai Voice Over (VO) Talent & Broadcaster. Bedanya apa, sih, sama dubber? Simak terus sampai tuntas, ya!</p>
            <p className='fw-bold mt-5 my-2' style={{ fontSize:"42px", color:"#1B6A68" }}>Motivasi Gap Year demi Kuliah di ITB</p>
            <div className="gambar" >
            
            </div>
            <p className='mt-4 my-2' style={{ fontSize:"20px", color:"#1B6A68" }}>Bisa dibilang, dulu itu Esa salah satu siswa SMA yang nggak terlalu mikirin kuliah. Malah tadinya, dia nggak kepikiran buat kuliah sama sekali. Punya hobi di bidang musik, Esa malah maunya langsung bekerja menjadi musisi atau audio engineer. Apalagi waktu sekolah, dia juga nggak rajin-rajin banget.</p>
            <p className='mt-4 my-2' style={{ fontSize:"20px", color:"#1B6A68" }}>Tapi menjelang musim ujian, prinsip Esa ini malah tergoyahkan. Hampir seluruh teman-temannya belajar untuk masuk kampus impian. Dari situ, Esa terbawa suasana dan mulai memikirkan jurusan yang kira-kira sejalan dengan hobinya.</p>
            <p className='mt-4 my-2' style={{ fontSize:"20px", color:"#1B6A68" }}>Setelah banyak konseling ke orang sekitarnya, seperti orang tua, om, tante, pilihan Esa akhirnya jatuh pada Jurusan Teknik Mesin dan Dirgantara Institut Teknologi Bandung (ITB). Dia mulai mengejar ketertinggalan belajarnya menggunakan Zenius, bahkan sampai ikut kelas offline-nya, lho! Yap, Esa belajar pakai Zenius saat dulu masih ada kelas offline-nya.</p>
            <p className='fw-bold mt-4 my-2' style={{ fontSize:"20px", color:"#1B6A68" }}>Dua bulan menuju ujian tulis, Esa mulai menyusun strategi belajarnya: mulai dari membuat jadwal belajar, ceklis materi, sampai latihan-latihan soal. Semua dia lakukan dengan penuh semangat dan komitmen. Tetapi, di SBMPTN pertama buatnya itu, Esa belum berhasil menguasai seluruh materi ujian dan gagal masuk ITB.</p>
            <p className='mt-4 my-2' style={{ fontSize:"20px", color:"#1B6A68" }}>Esa sempat menyesal kenapa enggak belajar serius dari awal. Saat perasaannya sedang down saat itu, dia baru tahu rupanya tante dan pamannya yang Esa kagumi ternyata pernah jadi pejuang gap year! Mereka pun tetap bisa sukses dengan cara mereka sendiri. Motivasi gap year langsung muncul dari situ. Esa tersadar, “Oke, mungkin gap year juga bisa menjadi solusi terbaik buat gue.”</p>
            <p className='mt-4 my-2' style={{ fontSize:"20px", color:"#1B6A68" }}>Setelah menjalani gap year, malah Esa merasa masa-masa itu banyak manfaatnya. Dia jadi punya waktu lebih buat explore diri, melihat berbagai macam sudut pandang dan realita baru, dan juga bisa memantapkan jurusan mana yang bakalan cocok buat dia.</p>
            <div className="kutipan px-4  pt-3 pb-4 my-4" >
              <p className='mt-4 my-2' style={{ fontSize:"20px", color:"#DD8100" }}>Tapi, Esa tetap yakin kalau memaksakan untuk masuk kampus lain saat itu, dia belum tentu bisa enjoy atau fokus kuliah. Ditambah kalau tiba-tiba di tengah jalan mandek, sama aja kayak buang-buang duit… </p>
            </div>
            <p className='mt-4 my-2' style={{ fontSize:"20px", color:"#1B6A68" }}>Makanya, kalau banyak yang bingung mending gap year atau kuliah seadanya, Esa nggak menyarankan buat maksain dengan pemikiran ‘yang penting kuliah’.</p>
            <div className="kutipan px-4  pt-3 pb-4 my-4" >
              <p className='mt-4 my-2' style={{ fontSize:"20px", color:"#DD8100" }}>Tapi kan enggak semua orang tua mau mengerti gap year juga bisa jadi pilihan…</p>
            </div>
            <p className='mt-4 my-2' style={{ fontSize:"20px", color:"#1B6A68" }}>Nah, buat elo yang masih bingung cara memberitahu orang tua soal rencana gap year, Esa berbagi tips. Yang pertama, elo mesti tahu dulu kapan orang tua elo bisa diajak ngobrol santai. Yang jelas sih jangan pas orang tua elo lagi capek, ya.</p>
            <p className='mt-4 mt-2 mb-5 ' style={{ fontSize:"20px", color:"#1B6A68" }}>Kalau sudah ketemu waktu yang pas, elo bisa mulai presentasikan tujuan dan motivasi gap year dari diri elo. Eitss, bukan berarti elo mesti buat PPT di laptop, tapi yakinkan dengan data-data dan realita yang ada.</p>
            
            <p className='fw-bold mt-5 ' style={{ fontSize:"42px", color:"#1B6A68" }}>Tags</p>
            <div className="row">
              <div className="col-1">
                <p className=' text-center mb-5 py-1 px-2' style={{ fontSize:"24px", color:"#1B6A68", backgroundColor:"#ffffff", borderRadius:"10px" }}>UTBK</p>
              </div>
              <div className="col-2">
                <p className=' text-center mb-5 py-1 px-2' style={{ fontSize:"24px", color:"#1B6A68", backgroundColor:"#ffffff", borderRadius:"10px" }}>Tips & Trik</p>
              </div>
              <div className="col-1">
                <p className=' text-center mb-5 py-1 px-2' style={{ fontSize:"24px", color:"#1B6A68", backgroundColor:"#ffffff", borderRadius:"10px" }}>Ujian</p>
              </div>
            </div>
          </div>
        </section>

        {/* share */}
        <section id='share' className=''>
          <div className="container my-5">
            <div className="row">
              <p className='fw-bold text-center py-1 px-2' style={{ fontSize:"42px", color:"#1B6A68" }}>Bagikan ke Temanmu</p>
            </div>
            <div className="row justify-content-center mt-5">
              <div className="col-6 mb-5 text-center">
                <img style={{ width: "15%", backgroundColor: "#1B6A68", borderRadius:"50%", padding: "1%" }} className="img2 mx-3" src={process.env.PUBLIC_URL + '/icon/wa.png'} alt="" />
                <img style={{ width: "15%", backgroundColor: "#1B6A68", borderRadius:"50%", padding: "1%" }} className="img2 mx-3" src={process.env.PUBLIC_URL + '/icon/wa.png'} alt="" />
                <img style={{ width: "15%", backgroundColor: "#1B6A68", borderRadius:"50%", padding: "1%" }} className="img2 mx-3" src={process.env.PUBLIC_URL + '/icon/wa.png'} alt="" />
                <img style={{ width: "15%", backgroundColor: "#1B6A68", borderRadius:"50%", padding: "1%" }} className="img2 mx-3" src={process.env.PUBLIC_URL + '/icon/wa.png'} alt="" />
              </div>
            </div>
          </div>
        </section>
        {/* footer */}
        <Footer/>
    </div>
  );
}

export default index;