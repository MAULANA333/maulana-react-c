# smart-calculator
simple HTML  JS  CSS  Calculator
